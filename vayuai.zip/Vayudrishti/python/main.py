import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import uvicorn

from services.air_quality import get_air_quality_analysis
from services.pollution_analysis import analyze_pollution_sources
from services.risk_engine import calculate_environmental_risk
from services.route_exposure import calculate_route_exposure
from services.intervention import simulate_intervention
from services.wind_pipeline import get_wind_pipeline

app = FastAPI(
    title="AEROTRACE AI Intelligence Service",
    description="Environmental analytics, risk scoring, route exposure, and intervention simulation",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalyzeRequest(BaseModel):
    aqi: float = Field(..., ge=0)
    pm25: float = Field(..., ge=0)
    pm10: float = Field(..., ge=0)
    location: Optional[Dict[str, Any]] = None
    weather: Optional[Dict[str, Any]] = None

class RiskRequest(BaseModel):
    aqi: float = Field(..., ge=0)
    pm25: float = Field(..., ge=0)
    pm10: float = Field(..., ge=0)
    trend: Optional[str] = "STABLE"
    route_exposure: Optional[float] = None

class RouteExposureRequest(BaseModel):
    origin: str
    destination: str
    direct_distance_km: Optional[float] = 8.2
    direct_duration_min: Optional[float] = 25.0
    base_aqi: Optional[float] = 184.0

class InterventionRequest(BaseModel):
    current_aqi: float = Field(..., ge=0)
    traffic_reduction: float = Field(0.0, ge=0, le=100)
    industrial_reduction: float = Field(0.0, ge=0, le=100)
    open_burning_reduction: float = Field(0.0, ge=0, le=100)
    sources: Optional[List[Dict[str, Any]]] = None

@app.get("/health")
async def health():
    return {
        "success": True,
        "status": "OK",
        "service": "AEROTRACE Python Intelligence Service",
        "version": "1.0.0"
    }

@app.post("/analyze")
async def analyze(req: AnalyzeRequest):
    try:
        res = analyze_pollution_sources(
            aqi=req.aqi,
            pm25=req.pm25,
            pm10=req.pm10,
            location=req.location,
            weather=req.weather
        )
        return {"success": True, "status": "LIVE", "data": res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/risk")
async def risk(req: RiskRequest):
    try:
        res = calculate_environmental_risk(
            aqi=req.aqi,
            pm25=req.pm25,
            pm10=req.pm10,
            trend=req.trend,
            route_exposure=req.route_exposure
        )
        return {"success": True, "status": "LIVE", "data": res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/route-exposure")
async def route_exposure(req: RouteExposureRequest):
    try:
        res = calculate_route_exposure(
            origin=req.origin,
            destination=req.destination,
            direct_distance_km=req.direct_distance_km,
            direct_duration_min=req.direct_duration_min,
            base_aqi=req.base_aqi
        )
        return {"success": True, "status": "LIVE", "data": res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/intervention")
async def intervention(req: InterventionRequest):
    try:
        res = simulate_intervention(
            current_aqi=req.current_aqi,
            traffic_reduction=req.traffic_reduction,
            industrial_reduction=req.industrial_reduction,
            open_burning_reduction=req.open_burning_reduction,
            sources=req.sources
        )
        return {"success": True, "status": "LIVE", "data": res}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class WindPredictRequest(BaseModel):
    city: str = Field(..., example="Kolkata")
    forecast_months: Optional[int] = Field(12, ge=1, le=24)

class WindAnomalyRequest(BaseModel):
    city: str = Field(..., example="Kolkata")
    contamination: Optional[float] = Field(0.08, ge=0.01, le=0.25)

@app.get("/wind/cities")
async def wind_cities():
    try:
        pipeline = get_wind_pipeline()
        cities = pipeline.get_supported_cities()
        return {"success": True, "status": "LIVE", "cities": cities}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/wind/history")
async def wind_history(city: str = "Kolkata"):
    try:
        pipeline = get_wind_pipeline()
        res = pipeline.get_city_history(city)
        if "error" in res:
            raise HTTPException(status_code=404, detail=res["error"])
        return {"success": True, "status": "LIVE", "data": res}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/wind/predict")
async def wind_predict(req: WindPredictRequest):
    try:
        pipeline = get_wind_pipeline()
        res = pipeline.predict_wind_flow(city=req.city, forecast_months=req.forecast_months)
        if "error" in res:
            raise HTTPException(status_code=404, detail=res["error"])
        return {"success": True, "status": "LIVE", "data": res}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/wind/anomalies")
async def wind_anomalies(req: WindAnomalyRequest):
    try:
        pipeline = get_wind_pipeline()
        res = pipeline.detect_anomalies(city=req.city, contamination=req.contamination)
        if "error" in res:
            raise HTTPException(status_code=404, detail=res["error"])
        return {"success": True, "status": "LIVE", "data": res}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
