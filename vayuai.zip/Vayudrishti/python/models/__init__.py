"""
AEROTRACE AI - ML Models Package (Future extension architecture)
"""
