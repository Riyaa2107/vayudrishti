"""
Air Quality normalization and helper calculations.
"""
from typing import Dict, Any, Optional

def get_air_quality_analysis(lat: float, lng: float, raw_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Normalizes air quality metrics and computes pollutant ratios.
    """
    if raw_data:
        aqi = raw_data.get("aqi", 184)
        pm25 = raw_data.get("pm25", 112)
        pm10 = raw_data.get("pm10", 178)
        source = raw_data.get("source", "Google Maps Air Quality API")
        status = raw_data.get("status", "LIVE")
    else:
        # Default demo values
        aqi = 184
        pm25 = 112
        pm10 = 178
        source = "DEMO DATA"
        status = "DEMO"

    # Determine category based on standard AQI brackets
    if aqi <= 50:
        category = "Good"
        color = "#00e400"
    elif aqi <= 100:
        category = "Moderate"
        color = "#ffff00"
    elif aqi <= 150:
        category = "Unhealthy for Sensitive Groups"
        color = "#ff7e00"
    elif aqi <= 200:
        category = "Unhealthy"
        color = "#ff0000"
    elif aqi <= 300:
        category = "Very Unhealthy"
        color = "#8f3f97"
    else:
        category = "Hazardous"
        color = "#7e0023"

    pm_ratio = round(pm25 / max(pm10, 1.0), 2)

    return {
        "status": status,
        "location": {"lat": lat, "lng": lng},
        "aqi": aqi,
        "pm25": pm25,
        "pm10": pm10,
        "category": category,
        "color": color,
        "pm_ratio": pm_ratio,
        "source": source
    }
