"""
Intervention Scenario Simulation Engine.
Models hypothetical air quality improvements resulting from policy interventions
including traffic restrictions, industrial emission caps, and open biomass burning bans.

CLASSIFICATION: SIMULATION
"""
from typing import Dict, Any, List, Optional

def simulate_intervention(
    current_aqi: float,
    traffic_reduction: float = 0.0,
    industrial_reduction: float = 0.0,
    open_burning_reduction: float = 0.0,
    sources: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    Computes projected AQI and particulate reduction based on sector contribution weights.
    """
    # Extract baseline weights or use standard urban weights
    traffic_weight = 0.72
    industrial_weight = 0.18
    burning_weight = 0.10

    if sources:
        for s in sources:
            name = s.get("name", "").lower()
            val = float(s.get("contribution", 0)) / 100.0
            if "traffic" in name or "vehic" in name:
                traffic_weight = val
            elif "indust" in name:
                industrial_weight = val
            elif "burn" in name:
                burning_weight = val

    # Non-linear atmospheric response factor: Particulates have a background non-anthropogenic floor (~25 AQI)
    background_floor = 28.0
    anthropogenic_aqi = max(0.0, current_aqi - background_floor)

    # Calculate fractional sector reduction
    traffic_drop = (traffic_reduction / 100.0) * traffic_weight
    industrial_drop = (industrial_reduction / 100.0) * industrial_weight
    burning_drop = (open_burning_reduction / 100.0) * burning_weight

    total_drop_fraction = traffic_drop + industrial_drop + burning_drop
    aqi_reduction_points = anthropogenic_aqi * total_drop_fraction

    projected_aqi = max(background_floor, round(current_aqi - aqi_reduction_points, 1))
    reduction_pct = round(((current_aqi - projected_aqi) / max(current_aqi, 1.0)) * 100.0, 1)

    # Determine simulated category
    if projected_aqi <= 50:
        simulated_category = "Good"
        color = "#00e400"
    elif projected_aqi <= 100:
        simulated_category = "Moderate"
        color = "#ffff00"
    elif projected_aqi <= 150:
        simulated_category = "Unhealthy for Sensitive Groups"
        color = "#ff7e00"
    elif projected_aqi <= 200:
        simulated_category = "Unhealthy"
        color = "#ff0000"
    else:
        simulated_category = "Very Unhealthy"
        color = "#8f3f97"

    # Insights on policy effectiveness
    insights = []
    if traffic_reduction >= 30:
        insights.append(f"High traffic reduction ({traffic_reduction}%) yields the steepest improvement due to heavy urban vehicular dominance.")
    if open_burning_reduction >= 50:
        insights.append("Eliminating biomass burning directly reduces highly toxic polycyclic organic aerosols.")
    if projected_aqi < 100 and current_aqi >= 150:
        insights.append("Policy combination successfully transitions the zone from Unhealthy to Moderate category!")

    return {
        "classification": "SIMULATION",
        "current_aqi": round(current_aqi, 1),
        "projected_aqi": projected_aqi,
        "absolute_reduction": round(current_aqi - projected_aqi, 1),
        "estimated_reduction_pct": reduction_pct,
        "projected_category": simulated_category,
        "projected_color": color,
        "inputs": {
            "traffic_reduction_pct": traffic_reduction,
            "industrial_reduction_pct": industrial_reduction,
            "open_burning_reduction_pct": open_burning_reduction
        },
        "insights": insights,
        "disclaimer": "Scenario model output based on linear-damping aerosol response. Not an atmospheric dispersion chemical transport validation."
    }
