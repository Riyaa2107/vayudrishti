"""
Vayudrishti AI - Wind Flow Predictive Machine Learning & Anomaly Detection Pipeline
Mathematical formulation:
- Cartesian Vector Decomposition (Zonal u, Meridional v)
- Harmonic Seasonal Regression Forecaster (1 to 12-month horizon)
- Dual-Ensemble Anomaly Detector (Isolation Forest + Seasonal Z-Score / IQR)
"""

import os
import math
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import Ridge

# Resolve paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CSV_PATH = os.path.join(BASE_DIR, 'data', 'raw', 'wind_telemetry_5yr.csv')
JSON_PATH = os.path.join(BASE_DIR, 'data', 'processed', 'wind_telemetry_5yr.json')

MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
]

CARDINAL_DIRECTIONS = [
    'N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE',
    'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'
]

def deg_to_cardinal(deg: float) -> str:
    """Map 0-360 degrees to 16-point cardinal compass text."""
    deg = (deg % 360 + 360) % 360
    idx = int((deg + 11.25) / 22.5) % 16
    return CARDINAL_DIRECTIONS[idx]

def vector_decompose(speed: float, deg: float):
    """Decompose wind into meteorological Cartesian vector components (u, v)."""
    rad = math.radians(deg)
    u = -speed * math.sin(rad)
    v = -speed * math.cos(rad)
    return u, v

def vector_reconstruct(u: float, v: float):
    """Reconstruct scalar speed and dominant angle from Cartesian vector components."""
    speed = math.hypot(u, v)
    rad = math.atan2(-u, -v)
    deg = (math.degrees(rad) + 360) % 360
    return round(speed, 2), round(deg, 1)

def get_ventilation_status(speed: float) -> Dict[str, str]:
    """Assess atmospheric dispersion and particulate trapping potential based on wind velocity."""
    if speed < 5.0:
        return {
            "level": "CRITICAL_STAGNATION",
            "label": "Stagnation Hazard",
            "color": "#ef4444",
            "impact": "Severe boundary layer trapping. Particulates (PM2.5/PM10) accumulate rapidly near ground level."
        }
    elif speed < 10.0:
        return {
            "level": "MODERATE_DISPERSION",
            "label": "Moderate Ventilation",
            "color": "#f59e0b",
            "impact": "Adequate atmospheric mixing under normal conditions; urban street canyons may experience localized hotspots."
        }
    else:
        return {
            "level": "OPTIMAL_VENTILATION",
            "label": "Strong Dispersion",
            "color": "#27a644",
            "impact": "High ventilation coefficient. Active dilution and rapid horizontal advection of airborne particulates."
        }

class WindIntelligencePipeline:
    def __init__(self):
        self.df: Optional[pd.DataFrame] = None
        self._load_dataset()

    def _load_dataset(self):
        """Load 5-year multi-city telemetry dataset."""
        if os.path.exists(CSV_PATH):
            self.df = pd.read_csv(CSV_PATH)
        elif os.path.exists(JSON_PATH):
            with open(JSON_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
            records = []
            for city, item in data.items():
                for row in item.get('timeline', []):
                    records.append(row)
            self.df = pd.DataFrame(records)
        else:
            raise FileNotFoundError(f"Neither {CSV_PATH} nor {JSON_PATH} could be found.")

        # Ensure numeric columns
        self.df['avg_wind_speed_kmph'] = pd.to_numeric(self.df['avg_wind_speed_kmph'], errors='coerce')
        self.df['dominant_wind_direction_deg'] = pd.to_numeric(self.df['dominant_wind_direction_deg'], errors='coerce')
        self.df['month_num'] = self.df['month'].apply(lambda m: MONTH_NAMES.index(m) + 1 if m in MONTH_NAMES else 1)

        # Decompose vectors
        u_vals, v_vals = [], []
        for _, row in self.df.iterrows():
            u, v = vector_decompose(row['avg_wind_speed_kmph'], row['dominant_wind_direction_deg'])
            u_vals.append(u)
            v_vals.append(v)
        self.df['u_vector'] = u_vals
        self.df['v_vector'] = v_vals

    def get_supported_cities(self) -> List[Dict[str, Any]]:
        """Return list of supported cities with geographic coordinates and record counts."""
        cities = []
        for city_name, group in self.df.groupby('city'):
            first_row = group.iloc[0]
            cities.append({
                "city": city_name,
                "latitude": float(first_row['latitude']),
                "longitude": float(first_row['longitude']),
                "records_count": int(len(group)),
                "years_range": f"{int(group['year'].min())}-{int(group['year'].max())}",
                "mean_speed_kmph": round(float(group['avg_wind_speed_kmph'].mean()), 2)
            })
        return cities

    def get_city_history(self, city: str) -> Dict[str, Any]:
        """Fetch full chronological 5-year timeline for a specific city."""
        city_data = self.df[self.df['city'].str.lower() == city.lower()].sort_values(['year', 'month_num'])
        if city_data.empty:
            return {"error": f"City '{city}' not found in telemetry store"}

        timeline = []
        for _, row in city_data.iterrows():
            spd = float(row['avg_wind_speed_kmph'])
            deg = float(row['dominant_wind_direction_deg'])
            timeline.append({
                "year": int(row['year']),
                "month": row['month'],
                "month_num": int(row['month_num']),
                "speed_kmph": spd,
                "direction_deg": deg,
                "cardinal": deg_to_cardinal(deg),
                "u_vector": round(float(row['u_vector']), 2),
                "v_vector": round(float(row['v_vector']), 2),
                "ventilation": get_ventilation_status(spd)
            })

        first_row = city_data.iloc[0]
        return {
            "city": city,
            "latitude": float(first_row['latitude']),
            "longitude": float(first_row['longitude']),
            "total_months": len(timeline),
            "timeline": timeline
        }

    def predict_wind_flow(self, city: str, forecast_months: int = 12) -> Dict[str, Any]:
        """
        Predict future wind speed, dominant direction, and Cartesian flow vectors.
        Uses Cartesian Ridge Regression with seasonal Fourier harmonics to avoid angle wrapping anomalies.
        """
        city_data = self.df[self.df['city'].str.lower() == city.lower()].sort_values(['year', 'month_num'])
        if city_data.empty:
            return {"error": f"City '{city}' not found"}

        # Build feature matrix
        # X: [sin(2pi m/12), cos(2pi m/12), sin(4pi m/12), cos(4pi m/12), t_norm]
        X = []
        y_u = []
        y_v = []
        y_speed = []

        for idx, (_, row) in enumerate(city_data.iterrows()):
            m = row['month_num']
            t_norm = idx / len(city_data)
            X.append([
                math.sin(2 * math.pi * m / 12),
                math.cos(2 * math.pi * m / 12),
                math.sin(4 * math.pi * m / 12),
                math.cos(4 * math.pi * m / 12),
                t_norm
            ])
            y_u.append(row['u_vector'])
            y_v.append(row['v_vector'])
            y_speed.append(row['avg_wind_speed_kmph'])

        X = np.array(X)
        y_u = np.array(y_u)
        y_v = np.array(y_v)
        y_speed = np.array(y_speed)

        # Train models for u and v components
        model_u = Ridge(alpha=1.0)
        model_v = Ridge(alpha=1.0)
        model_spd = Ridge(alpha=0.5)

        model_u.fit(X, y_u)
        model_v.fit(X, y_v)
        model_spd.fit(X, y_speed)

        # In-sample residuals for confidence interval estimate
        preds_in_spd = model_spd.predict(X)
        residuals = y_speed - preds_in_spd
        std_error = np.std(residuals) if len(residuals) > 0 else 0.85

        # Generate future forecast
        last_year = int(city_data['year'].max())
        last_month = int(city_data['month_num'].iloc[-1])

        forecast = []
        cur_year = last_year
        cur_m = last_month
        total_hist_len = len(city_data)

        for step in range(1, forecast_months + 1):
            cur_m += 1
            if cur_m > 12:
                cur_m = 1
                cur_year += 1

            t_future = (total_hist_len + step) / total_hist_len
            feat = np.array([[
                math.sin(2 * math.pi * cur_m / 12),
                math.cos(2 * math.pi * cur_m / 12),
                math.sin(4 * math.pi * cur_m / 12),
                math.cos(4 * math.pi * cur_m / 12),
                t_future
            ]])

            pred_u = float(model_u.predict(feat)[0])
            pred_v = float(model_v.predict(feat)[0])
            pred_spd_direct = float(model_spd.predict(feat)[0])

            rec_spd, rec_deg = vector_reconstruct(pred_u, pred_v)
            # Blend direct speed and vector magnitude
            final_spd = round(max(2.0, (rec_spd * 0.4 + pred_spd_direct * 0.6)), 2)

            ci_lower = float(round(max(1.0, final_spd - 1.645 * std_error), 2))
            ci_upper = float(round(final_spd + 1.645 * std_error, 2))

            forecast.append({
                "step": step,
                "year": cur_year,
                "month": MONTH_NAMES[cur_m - 1],
                "month_num": cur_m,
                "predicted_speed_kmph": final_spd,
                "predicted_direction_deg": rec_deg,
                "cardinal": deg_to_cardinal(rec_deg),
                "ci_lower_85": ci_lower,
                "ci_upper_85": ci_upper,
                "u_vector": round(pred_u, 2),
                "v_vector": round(pred_v, 2),
                "ventilation": get_ventilation_status(final_spd)
            })

        first_row = city_data.iloc[0]
        return {
            "city": city,
            "latitude": float(first_row['latitude']),
            "longitude": float(first_row['longitude']),
            "forecast_horizon_months": forecast_months,
            "model_architecture": "Harmonic Vector Ridge Regression (u, v Cartesian)",
            "mean_residual_error": round(float(std_error), 3),
            "forecast": forecast
        }

    def detect_anomalies(self, city: str, contamination: float = 0.08) -> Dict[str, Any]:
        """
        Multi-variate Anomaly Detection Pipeline.
        Combines Isolation Forest and Seasonal Rolling Z-Scores to flag:
        - Critical Stagnation (particulate buildup / smog risk)
        - Extreme Wind Gust / Cyclone events
        - Directional Shear / Abnormal seasonal inversions
        """
        city_data = self.df[self.df['city'].str.lower() == city.lower()].sort_values(['year', 'month_num']).copy()
        if city_data.empty:
            return {"error": f"City '{city}' not found"}

        # 1. Isolation Forest on multi-dimensional wind features
        features = city_data[['avg_wind_speed_kmph', 'dominant_wind_direction_deg', 'u_vector', 'v_vector']].values
        iso = IsolationForest(contamination=contamination, random_state=42)
        city_data['iso_outlier'] = iso.fit_predict(features)
        city_data['iso_score'] = iso.decision_function(features)

        # 2. Monthly Climatological Normal & Z-Scores
        monthly_stats = {}
        for m in range(1, 13):
            m_slice = city_data[city_data['month_num'] == m]['avg_wind_speed_kmph']
            m_mean = m_slice.mean()
            m_std = m_slice.std() if len(m_slice) > 1 and m_slice.std() > 0.05 else 0.4
            monthly_stats[m] = {"mean": m_mean, "std": m_std}

        anomalies = []
        historical_audit = []

        for _, row in city_data.iterrows():
            m = row['month_num']
            spd = float(row['avg_wind_speed_kmph'])
            deg = float(row['dominant_wind_direction_deg'])
            m_stat = monthly_stats[m]
            z_score = (spd - m_stat['mean']) / m_stat['std']

            is_iso_flag = (row['iso_outlier'] == -1)
            is_stat_flag = abs(z_score) >= 1.6 or spd < 5.0 or spd > 22.0

            anomaly_type = None
            severity = "NORMAL"
            impact_advisory = None

            if spd < 5.2 or z_score <= -1.75:
                anomaly_type = "STAGNATION_HAZARD"
                severity = "CRITICAL" if (spd < 4.6 or z_score <= -2.1) else "WARNING"
                impact_advisory = (
                    f"Acute wind calm ({spd} km/h, Z={z_score:.2f}). Ventilation collapse triggers particulate (PM2.5) "
                    f"accumulation. Recommend restrictive traffic emissions throttling and mist cannons."
                )
            elif spd >= 21.0 or z_score >= 2.0:
                anomaly_type = "EXTREME_GUST_STORM"
                severity = "CRITICAL" if z_score >= 2.4 else "WARNING"
                impact_advisory = (
                    f"Unusual high-speed storm advection ({spd} km/h, Z={z_score:.2f}). High mechanical turbulence "
                    f"and fugitive dust resuspension risk."
                )
            elif is_iso_flag:
                anomaly_type = "DIRECTIONAL_SHEAR"
                severity = "WARNING"
                impact_advisory = (
                    f"Unusual wind vector departure ({deg_to_cardinal(deg)} at {deg}°). "
                    f"Atypical seasonal trajectory alters regional plume advection corridors."
                )

            is_anomaly = anomaly_type is not None

            entry = {
                "year": int(row['year']),
                "month": row['month'],
                "month_num": int(m),
                "speed_kmph": spd,
                "direction_deg": deg,
                "cardinal": deg_to_cardinal(deg),
                "expected_speed_kmph": round(float(m_stat['mean']), 2),
                "z_score": round(float(z_score), 2),
                "is_anomaly": is_anomaly,
                "anomaly_type": anomaly_type,
                "severity": severity,
                "impact_advisory": impact_advisory
            }

            if is_anomaly:
                anomalies.append(entry)
            historical_audit.append(entry)

        first_row = city_data.iloc[0]
        return {
            "city": city,
            "latitude": float(first_row['latitude']),
            "longitude": float(first_row['longitude']),
            "total_months_evaluated": len(historical_audit),
            "anomalies_detected_count": len(anomalies),
            "stagnation_hazards_count": sum(1 for a in anomalies if a['anomaly_type'] == 'STAGNATION_HAZARD'),
            "gust_events_count": sum(1 for a in anomalies if a['anomaly_type'] == 'EXTREME_GUST_STORM'),
            "shear_events_count": sum(1 for a in anomalies if a['anomaly_type'] == 'DIRECTIONAL_SHEAR'),
            "flagged_anomalies": anomalies,
            "audit_stream": historical_audit
        }

# Global singleton
_pipeline_instance: Optional[WindIntelligencePipeline] = None

def get_wind_pipeline() -> WindIntelligencePipeline:
    global _pipeline_instance
    if _pipeline_instance is None:
        _pipeline_instance = WindIntelligencePipeline()
    return _pipeline_instance
