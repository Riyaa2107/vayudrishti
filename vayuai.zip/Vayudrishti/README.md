# VayuDrishti AI (वायुदृष्टि)
> **Environmental Intelligence & Atmospheric Command Hub**  
> *From Detection to Decision &mdash; Real-Time Air Quality, Wind Dynamics, Satellite Fire Radars & Human-in-the-Loop Verification*

---

## 🌟 Overview

**VayuDrishti AI** is a full-stack environmental intelligence platform designed for monitoring, predicting, and verifying urban atmospheric conditions. Engineered to the **Linear Design Standard** (`#010102` deep canvas, tactile hairlines, and refined typography), VayuDrishti bridges the gap between satellite remote sensing, predictive machine learning, and local human ground-truth observations.

Whether operating in fully autonomous **Offline / Demo Mode** or with live satellite telemetry and AI keys, VayuDrishti guarantees a non-blocking, zero-crash command experience.

---

## 🚀 Key Modules & Capabilities

### 1. Linear Design System User Interface
- **Palette**: Deepest near-black canvas (`#010102`), 4-step surface hierarchy (`#0f1011` to `#191a1b`), hairline borders (`#23252a`), and Linear lavender-blue chromatic accents (`#5e6ad2`).
- **Typography**: Inter for display headers and JetBrains Mono for telemetry metrics.
- **Glassmorphic Overlays**: Subtle inset top edge highlights (`inset 0 1px 0 0 rgba(255, 255, 255, 0.06)`).

### 2. Operator Authentication & Clearance Suite
- **Role Clearance Matrix**: Field Environmental Researcher, Urban Policy Planner, Citizen Air Quality Explorer, Chief Atmospheric Director.
- **Persistent Account Registry**: Server-side user accounts persisted to `data/users.json`.
- **Live Password Strength Meter**: Dynamic 4-state indicator with real-time feedback.
- **1-Click Instant Demo Personas**:
  - `🔬 Dr. Sharma` &mdash; Field Environmental Researcher
  - `🏛️ Policy Cell` &mdash; Urban Policy Planner
  - `🛰️ Dir. Verma` &mdash; Chief Atmospheric Director
- **Fast Single Sign-On (SSO)**: Google Workspace and National Informatics Centre (NIC) gateway demo entries.

### 3. Satellite Map & Command Hub
- **High-Resolution Earth Observation**: Integrated ESRI World Imagery satellite tiles and CartoDB Dark Matter.
- **Live Map Controls**: One-click switching between Satellite Imagery (`🛰️`), Dark Vector (`🌃`), and Tactical Animated Radar HUD (`⚡`).
- **Telemetry Ladder**: Live AQI, Fine Particulate (PM2.5), Coarse Particulate (PM10), and Environmental Risk Score.
- **Source Apportionment**: Heuristic aerosol diagnostic attributing particulate load between Traffic (72%), Industrial Activity (18%), and Open Burning (10%).

### 4. Commute Transit & Policy Intervention Simulator
- **Corridor Inhalation Exposure**: Side-by-side exposure modeling comparing direct arterial bottlenecks against lower-exposure eco-bypass green corridors (up to **37.8% lower estimated exposure**).
- **Policy Scenario Lab**: Interactive sliders for Traffic & Freight Restrictions, Industrial Emission Caps, and Biomass Burning Bans with real-time projected AQI calculations.

### 5. Atmospheric Analytics & Predictive Splines
- **24-Hour Diurnal Curve**: Smooth cubic Bézier spline mapping boundary layer inversions and rush hour peaks.
- **PM2.5 / PM10 Stoichiometric Signature**: Bar ratio visualization identifying combustion vs mechanical dust dominance.
- **7-Day Predictive Forecast Spline**: Machine learning projection with confidence bands.
- **Concentric Source Donut**: Interactive breakdown of regional emission contributors.

### 6. Wind Dynamics & Anomaly Radar (5-Year Climatology)
- **5-Year Climatological Dataset (2020–2024)**: 300 monthly records across 5 Indian geographical regimes (Kolkata, Bangalore, Guwahati, Indore, Mumbai).
- **Cartesian Vector Decomposition**: Translates polar velocity into zonal ($u$) and meridional ($v$) vectors, eliminating polar wraparound discontinuity.
- **Harmonic Ridge Regression Forecasting**: 1–12 month projections with 85% normal dispersion confidence intervals.
- **Polar Advection Compass HUD**: Circular dial displaying prevailing vectors, cardinal directions, and atmospheric ventilation ratings.
- **Atmospheric Anomaly Engine (Isolation Forest)**:
  - **Stagnation Trap Hazards**: Wind speed $< 5.0\text{ km/h}$ flagged as severe particulate trapping inversions.
  - **Elevated Gust Events**: Wind speed $> 18.0\text{ km/h}$ flagged as surface dust resuspension.
  - **Directional Shears**: Seasonal departure $> 90^\circ$ flagged as regional advection shifts.

### 7. Real-Time Prediction Verification & Early Warning System
- **Prediction Verification Card ("Is this prediction accurate?")**:
  - Displays predicted AQI, PM2.5, current location, horizon selector (`1h` / `2h`), and timestamp.
  - 🟢 **YES, It matches**: Records confirmation, increases confidence score, and provides instant positive feedback.
  - 🔴 **NO, It's different**: Unfolds discrepancy options (*More polluted, Heavy traffic, Smoke/burning, Dust/construction, Cleaner, Weather changed, Other*) with custom notes.
  - **Live Community Agreement Display**: Real-time progress bar (e.g. `84% of nearby users agree with this prediction`).
- **Multi-Sensor Fire & Smoke Detection**:
  - Fuses Sentinel-3 / VIIRS satellite thermal hotspots, optical aerosol surges ($\text{PM}_{2.5}$ delta $+45\ \mu\text{g/m}^3$), surface wind vectors, and local human verifications.
  - Dynamic Linear confidence meter (`🔥 Fire Confidence: 87%`).
  - **Local Ground Truth Confirmation**: 🟢 YES boosts confidence score (up to 96%); 🔴 NO records "Not observed locally" and attenuates confidence score (down to 25%) without erasing satellite data.
- **Geospatial Hazard & Pollution Movement Map (`#simulatorMap`)**:
  - Interactive Leaflet radar map rendering active fire hotspot pins, animated smoke plume dispersion polygons along the wind vector, trajectory polylines, user location pin, and hazard buffer zones.
- **Real-Time Notification Center**:
  - Top navigation notification bell (🔔) with live unread badge.
  - Popover dropdown panel featuring active hazard alerts (`🔥 FIRE DETECTED`, `🌫️ SMOKE DETECTED`, `⚠️ AQI PREDICTION ALERT`) with distance, arrival windows, and action buttons.
  - **Alert Preferences Modal**: Configurable notification radius (`1 km`, `3 km`, `5 km`, `10 km`) and hazard category subscriptions.
  - Background 30-second polling loop for non-blocking telemetry refresh.

### 8. AI Assistant Studio
- Context-aware natural language assistant answering localized environmental questions.
- Built-in Speech Synthesis (TTS) voice readout.

---

## 🏗️ Architecture

```
                                      OPERATOR
                                         │
                                         ▼
                     HTML5 + CSS3 + Vanilla JavaScript (ES6+)
                     (Linear Design System • Leaflet CartoDB)
                                         │
                                         ▼
                                 Node.js + Express
                             (Gateway & Event Hub :8080)
                                         │
                 ┌───────────────────────┼───────────────────────┐
                 ▼                       ▼                       ▼
       Satellite & Maps API       Air Quality API        Vertex AI / Gemini
       (ESRI / Google Maps)     (Google Air Quality)      (GenAI Assistant)
                 │                       │
                 └───────────┬───────────┘
                             │
                             ▼
                      Python FastAPI
                (Intelligence Core :8000)
                             │
         ┌───────────────────┼───────────────────┐
         ▼                   ▼                   ▼
    Risk Engine      Pollution Analysis    Route Exposure
         │                   │                   │
         ▼                   ▼                   ▼
  Policy Simulator     Wind Dynamics      Anomaly Radar
                      (Harmonic Ridge)   (Isolation Forest)
```

---

## 📁 Directory Structure

```
Vayudrishti/
├── server.js                  # Express API Gateway server, verifications & fallbacks
├── package.json               # Node.js dependencies & scripts
├── .env.example               # Environment configuration template
├── .gitignore                 # Excludes node_modules, .env, venvs, and cache
├── DESIGN-linear.app.md       # Design system specification reference
├── start-full.bat             # 1-Click launcher for both Node.js and Python
├── start.bat                  # 1-Click launcher for Node.js gateway
├── README.md                  # Comprehensive platform documentation
│
├── public/                    # Frontend Client (Vanilla ES6+ & CSS)
│   ├── index.html             # Semantic Linear Single-Page Application
│   ├── style.css              # Linear Design System stylesheet
│   └── app.js                 # State store, Leaflet map, charts, & API client
│
├── python/                    # Python Intelligence & ML Service
│   ├── main.py                # FastAPI application entrypoint
│   ├── requirements.txt       # FastAPI, Uvicorn, Scikit-learn, NumPy, Pandas
│   └── services/              # Scientific Analytics & ML Modules
│       ├── wind_pipeline.py   # Harmonic ridge forecasting & anomaly detector
│       ├── risk_engine.py     # Multi-factor environmental risk model
│       ├── route_exposure.py  # Arterial vs eco-bypass exposure model
│       ├── pollution_analysis.py # Aerosol source apportionment heuristics
│       ├── intervention.py    # Policy intervention scenario simulation
│       └── air_quality.py     # Pollutant normalization & NAAQS brackets
│
├── data/                      # Environmental Datasets & Persistence Stores
│   ├── aqi_verifications.json # Community ground-truth observations
│   ├── fire_verifications.json# Ground-truth fire confirmation logs
│   ├── user_subscriptions.json# User alert preferences & radius
│   ├── users.json             # Persistent operator accounts registry
│   ├── raw/
│   │   └── wind_telemetry_5yr.csv  # 5-year climatological dataset (2020–2024)
│   ├── processed/
│   │   └── wind_telemetry_5yr.json # Pre-computed multi-city wind telemetry
│   └── metadata/
│       └── stations.json      # Ground monitoring stations metadata
│
├── models/                    # Model Checkpoints & Roadmap Documentation
│   └── README.md
│
└── reports/                   # Exported Environmental Reports
    └── .gitkeep
```

---

## ⚡ Quick Start Guide

### Prerequisites
- **Node.js** (v18.0 or newer) &mdash; [Download](https://nodejs.org/)
- **Python** (v3.9 or newer) &mdash; [Download](https://www.python.org/)
- **Git** &mdash; [Download](https://git-scm.com/)

---

### Option A: 1-Click Windows Launcher (Recommended)
Double-click `start-full.bat` in the repository root. This will automatically:
1. Start the Python FastAPI intelligence server on `http://127.0.0.1:8000`.
2. Start the Node.js gateway server on `http://localhost:8080`.
3. Open your default web browser to the Command Hub.

---

### Option B: Manual Terminal Launch

#### Step 1: Start Python Intelligence Service
```bash
cd python
python -m venv venv

# On Windows:
.\venv\Scripts\activate

# On macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
python main.py
```
*The FastAPI intelligence service will run on `http://127.0.0.1:8000`.*

#### Step 2: Start Node.js API Gateway
In a separate terminal window:
```bash
npm install
npm start
```
*The Node.js gateway will start on `http://localhost:8080`.*

#### Step 3: Open in Browser
Navigate to:
```
http://localhost:8080
```
Log in using any of the **1-Click Instant Demo Personas** (e.g. `Dr. Sharma`) or register a new operator profile.

---

## ⚙️ Environment Variables (Optional)

Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Configure your optional keys if live external services are desired:
```ini
PORT=8080
PYTHON_API_URL=http://127.0.0.1:8000

# Optional: Google Maps JavaScript API (for live Google Maps tiles)
GOOGLE_MAPS_API_KEY=your_google_maps_key_here

# Optional: Google Gemini / Vertex AI (for live AI conversational assistant)
GEMINI_API_KEY=your_gemini_api_key_here
GOOGLE_PROJECT_ID=your_project_id
GOOGLE_LOCATION=us-central1
```
*Note: If no keys are provided, VayuDrishti automatically operates in its high-fidelity built-in DEMO & Leaflet satellite mode without errors.*

---

## 🧪 Testing & Validation

Run the automated verification suite to validate all endpoints and syntax:
```bash
# Check syntax
node --check server.js
node --check public/app.js

# Test API endpoints
node -e "
const http = require('http');
http.get('http://localhost:8080/api/health', res => {
  res.on('data', d => console.log('Gateway Health:', d.toString()));
});
"
```

---

## 📤 Pushing to Your GitHub Repository

To upload this project to your GitHub account:

1. **Initialize Git & Stage Files**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: VayuDrishti AI Environmental Command Hub"
   ```

2. **Create a New Repository on GitHub**:
   - Go to [github.com/new](https://github.com/new).
   - Name your repository (e.g., `VayuDrishti` or `vayudrishti-ai`).
   - Do **NOT** check "Initialize with a README" (since we already have one).

3. **Link Remote and Push**:
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
   git push -u origin main
   ```

---

## 🛡️ License

This project is licensed under the **MIT License**.
