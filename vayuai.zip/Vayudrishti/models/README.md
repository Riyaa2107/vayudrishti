# Vayudrishti  - Predictive Machine Learning Model Registry

This directory is architected to host serialized ML models and checkpoints for future advanced analytics:

1. **AQI 24h/72h Forecasting**: Temporal transformer / LSTM neural network for micro-climate atmospheric projection.
2. **Pollution Hotspot Anomaly Detection**: Isolation Forests & autoencoders for detecting sudden industrial leaks and illegal burning spikes.
3. **Chemical Mass Balance & Source Apportionment**: Positive Matrix Factorization (PMF) and XGBoost classifiers for isotopic particulate fingerprinting.
4. **Transit Corridor Inhalation Model**: Graph Neural Network (GNN) estimating dynamic exposure gradients along street canyons.

*Note: Current production release utilizes Python FastAPI heuristic and mathematical scenario simulation engines.*
