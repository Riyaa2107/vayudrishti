/**
 * VAYUDRISHTI AI - Environmental Intelligence Platform
 * Vanilla JavaScript (ES6+), High-Precision Linear Vector Visualizations
 * Reference: DESIGN-linear.app.md
 */

(function () {
  'use strict';

  // Global Application State
  const state = {
    isLoggedIn: false,
    currentUser: {
      email: 'researcher@aerotrace.gov',
      role: 'Field Environmental Researcher',
      avatar: 'FR'
    },
    currentPage: 'page-login',
    currentCityKey: 'indore',
    location: {
      lat: 22.7533,
      lng: 75.8937,
      name: 'Vijay Nagar, Indore'
    },
    aqiData: {
      aqi: 184,
      pm25: 112,
      pm10: 178,
      category: 'Unhealthy',
      status: 'DEMO',
      source: 'DEMO DATA'
    },
    riskData: {
      score: 82,
      level: 'HIGH',
      advisory: 'High environmental risk. Limit outdoor exposure. Wear N95 masks.'
    },
    sources: [
      { name: 'Traffic', contribution: 72 },
      { name: 'Industrial Activity', contribution: 18 },
      { name: 'Open Burning', contribution: 10 }
    ],
    config: {
      hasMapsKey: false,
      hasGeminiKey: false,
      GOOGLE_MAPS_API_KEY: null
    },
    mapInstance: null,
    mapMode: 'DEMO',
    is3d: false,
    ttsEnabled: false,
    windData: {
      currentCity: 'Kolkata',
      horizonMonths: 12,
      history: [],
      forecast: [],
      anomalies: [],
      statistics: {},
      summary: {},
      activeAnomalyFilter: 'ALL',
      hoverPoint: null
    },
    verificationData: {
      activeHorizon: '1h',
      confirmed: false,
      disputed: false,
      disputedReason: null,
      stats: { totalReports: 17, confirmedCount: 14, disputedCount: 3, confirmedPct: 84 },
      fireConfidence: 87,
      fireStatusText: 'Potential fire detected nearby',
      fireEvents: [],
      groundConfirmed: false,
      userObservedDetails: null
    },
    notifications: [],
    unreadNotifCount: 3,
    alertPreferences: {
      enabled: true,
      radiusKm: 5,
      preferences: { fireAlert: true, smokeAlert: true, aqiAlert: true, discrepancyAlert: true }
    }
  };

  // City Presets
  const PRESETS = {
    'indore': { lat: 22.7533, lng: 75.8937, name: 'Vijay Nagar, Indore', origin: 'Vijay Nagar Square, Indore', dest: 'Rajwada Central, Indore' },
    'delhi': { lat: 28.6469, lng: 77.3160, name: 'Anand Vihar, Delhi', origin: 'Anand Vihar ISBT, Delhi', dest: 'Connaught Place, Delhi' },
    'mumbai': { lat: 19.0688, lng: 72.8704, name: 'Bandra Kurla Complex, Mumbai', origin: 'BKC Cyber City, Mumbai', dest: 'Nariman Point, Mumbai' },
    'kolkata': { lat: 22.5448, lng: 88.3426, name: 'Victoria Memorial, Kolkata', origin: 'Salt Lake Sector V, Kolkata', dest: 'Park Street, Kolkata' },
    'hyderabad': { lat: 17.4474, lng: 78.3762, name: 'HITEC City, Hyderabad', origin: 'HITEC City, Hyderabad', dest: 'Charminar, Hyderabad' },
    'bengaluru': { lat: 12.9166, lng: 77.6101, name: 'BTM Layout, Bengaluru', origin: 'BTM 2nd Stage, Bengaluru', dest: 'MG Road, Bengaluru' },
    'guwahati': { lat: 26.1856, lng: 91.7473, name: 'Pan Bazaar, Guwahati', origin: 'Pan Bazaar, Guwahati', dest: 'GS Road Dispur, Guwahati' }
  };

  let els = {};
  let radarAnimId = null;
  let leafletMap = null;
  let leafletSatLayer = null;
  let leafletDarkLayer = null;
  let leafletMarkersGroup = null;
  let activeMapType = 'SATELLITE';
  let simulatorLeafletMap = null;
  let simulatorOverlaysGroup = null;
  let environmentalPollInterval = null;

  // Initialize on Load
  document.addEventListener('DOMContentLoaded', () => {
    cacheDomElements();
    attachEventListeners();

    // Check if user has an explicit active session in this browser tab/window
    const isExplicitSession = sessionStorage.getItem('vayudrishti_active_session') === 'true';
    const savedUser = isExplicitSession ? (localStorage.getItem('vayudrishti_user') || localStorage.getItem('aerotrace_user')) : null;

    if (savedUser) {
      try {
        state.currentUser = JSON.parse(savedUser);
        handleSuccessfulLogin(true);
      } catch (e) {
        showLoginPage();
      }
    } else {
      showLoginPage();
    }

    // Load server configurations and background checks without blocking the initial UI view
    loadServerConfig();
    checkPythonHealth();
  });

  function showLoginPage() {
    state.isLoggedIn = false;
    if (els.appShell) {
      els.appShell.classList.add('hidden');
      els.appShell.classList.remove('active');
    }
    if (els.pageLogin) {
      els.pageLogin.classList.remove('hidden');
      els.pageLogin.classList.add('active');
    }
  }

  function cacheDomElements() {
    els = {
      // Pages
      pageLogin: document.getElementById('page-login'),
      appShell: document.getElementById('app-shell'),
      navTabs: document.querySelectorAll('.hand-tab'),
      pageViews: document.querySelectorAll('.content-viewport .page-view'),

      // Auth & Access Control
      loginForm: document.getElementById('loginForm'),
      loginEmail: document.getElementById('loginEmail'),
      loginPass: document.getElementById('loginPass'),
      loginRole: document.getElementById('loginRole'),
      loginSubmitBtn: document.getElementById('loginSubmitBtn'),
      rememberMe: document.getElementById('rememberMe'),
      demoQuickLoginBtn: document.getElementById('demoQuickLoginBtn'),
      logoutBtn: document.getElementById('logoutBtn'),
      operatorAvatar: document.getElementById('operatorAvatar'),
      operatorName: document.getElementById('operatorName'),
      operatorRole: document.getElementById('operatorRole'),
      navBrandLogo: document.getElementById('navBrandLogo'),

      // Extended Login & Register Suite
      tabBtnSignIn: document.getElementById('tabBtnSignIn'),
      tabBtnRegister: document.getElementById('tabBtnRegister'),
      linkToRegister: document.getElementById('linkToRegister'),
      linkToLogin: document.getElementById('linkToLogin'),
      registerForm: document.getElementById('registerForm'),
      regName: document.getElementById('regName'),
      regEmail: document.getElementById('regEmail'),
      regPass: document.getElementById('regPass'),
      regRole: document.getElementById('regRole'),
      regSubmitBtn: document.getElementById('regSubmitBtn'),
      passStrengthFill: document.getElementById('passStrengthFill'),
      passStrengthText: document.getElementById('passStrengthText'),
      togglePassVisibilityBtn: document.getElementById('togglePassVisibilityBtn'),
      ssoGoogleBtn: document.getElementById('ssoGoogleBtn'),
      ssoGovBtn: document.getElementById('ssoGovBtn'),
      personaBtn1: document.getElementById('personaBtn1'),
      personaBtn2: document.getElementById('personaBtn2'),
      personaBtn3: document.getElementById('personaBtn3'),
      forgotPassLink: document.getElementById('forgotPassLink'),
      forgotPassModal: document.getElementById('forgotPassModal'),
      closeForgotModalBtn: document.getElementById('closeForgotModalBtn'),
      forgotModalBackdrop: document.getElementById('forgotModalBackdrop'),
      sendRecoveryBtn: document.getElementById('sendRecoveryBtn'),
      recoveryEmail: document.getElementById('recoveryEmail'),
      authToast: document.getElementById('authToast'),

      // Global Nav
      globalCitySelector: document.getElementById('globalCitySelector'),
      globalStatusCapsule: document.getElementById('globalStatusCapsule'),
      globalDataStatusText: document.getElementById('globalDataStatusText'),
      footerPythonText: document.getElementById('footerPythonText'),
      footerGoogleText: document.getElementById('footerGoogleText'),

      // Metrics Cards
      aqiValue: document.getElementById('aqiValue'),
      aqiBadge: document.getElementById('aqiBadge'),
      aqiMeterFill: document.getElementById('aqiMeterFill'),
      aqiSourceText: document.getElementById('aqiSourceText'),
      aqiUpdatedText: document.getElementById('aqiUpdatedText'),
      pm25Value: document.getElementById('pm25Value'),
      pm25Exceed: document.getElementById('pm25Exceed'),
      pm10Value: document.getElementById('pm10Value'),
      riskScoreValue: document.getElementById('riskScoreValue'),
      riskLevelBadge: document.getElementById('riskLevelBadge'),
      riskAdvisoryText: document.getElementById('riskAdvisoryText'),

      // Map
      mapPanel: document.getElementById('map'),
      mapModeBadge: document.getElementById('mapModeBadge'),
      toggle3dBtn: document.getElementById('toggle3dBtn'),
      centerMapBtn: document.getElementById('centerMapBtn'),
      layerSatBtn: document.getElementById('layerSatBtn'),
      layerDarkBtn: document.getElementById('layerDarkBtn'),
      layerRadarBtn: document.getElementById('layerRadarBtn'),

      // Modal
      customLocModal: document.getElementById('customLocModal'),
      modalBackdrop: document.getElementById('modalBackdrop'),
      closeModalBtn: document.getElementById('closeModalBtn'),
      customLatInput: document.getElementById('customLatInput'),
      customLngInput: document.getElementById('customLngInput'),
      applyCustomCoordsBtn: document.getElementById('applyCustomCoordsBtn'),

      // Investigation
      investigateBtn: document.getElementById('investigateBtn'),
      trafficPct: document.getElementById('trafficPct'),
      trafficFill: document.getElementById('trafficFill'),
      industrialPct: document.getElementById('industrialPct'),
      industrialFill: document.getElementById('industrialFill'),
      burningPct: document.getElementById('burningPct'),
      burningFill: document.getElementById('burningFill'),
      sourceConfidence: document.getElementById('sourceConfidence'),
      aiExplanationText: document.getElementById('aiExplanationText'),
      recommendationsList: document.getElementById('recommendationsList'),

      // Alerts
      alertsFeed: document.getElementById('alertsFeed'),

      // Routes & Simulator
      routeOriginInput: document.getElementById('routeOriginInput'),
      routeDestInput: document.getElementById('routeDestInput'),
      calculateRouteBtn: document.getElementById('calculateRouteBtn'),
      directDist: document.getElementById('directDist'),
      directDur: document.getElementById('directDur'),
      directExposure: document.getElementById('directExposure'),
      ecoDist: document.getElementById('ecoDist'),
      ecoDur: document.getElementById('ecoDur'),
      ecoExposure: document.getElementById('ecoExposure'),
      exposureReductionText: document.getElementById('exposureReductionText'),
      routeRecText: document.getElementById('routeRecText'),

      trafficSlider: document.getElementById('trafficSlider'),
      trafficSliderVal: document.getElementById('trafficSliderVal'),
      industrialSlider: document.getElementById('industrialSlider'),
      industrialSliderVal: document.getElementById('industrialSliderVal'),
      burningSlider: document.getElementById('burningSlider'),
      burningSliderVal: document.getElementById('burningSliderVal'),
      simCurrentAqi: document.getElementById('simCurrentAqi'),
      simProjectedAqi: document.getElementById('simProjectedAqi'),
      simReductionPct: document.getElementById('simReductionPct'),
      simProjCat: document.getElementById('simProjCat'),
      simInsightsText: document.getElementById('simInsightsText'),

      // AI Bot Studio
      chatInput: document.getElementById('chatInput'),
      sendChatBtn: document.getElementById('sendChatBtn'),
      chatMessages: document.getElementById('chatMessages'),
      clearChatBtn: document.getElementById('clearChatBtn'),
      ttsToggleBtn: document.getElementById('ttsToggleBtn'),
      aiAssistantBadge: document.getElementById('aiAssistantBadge'),
      aiModelStatusText: document.getElementById('aiModelStatusText'),

      // Canvas Graphs
      canvasAqi24h: document.getElementById('canvasAqi24h'),
      canvasPmRatio: document.getElementById('canvasPmRatio'),
      canvasForecast: document.getElementById('canvasForecast'),
      canvasSourcesDonut: document.getElementById('canvasSourcesDonut'),

      // Wind Flow, Prediction & Anomaly Radar Elements
      pageWindFlow: document.getElementById('page-wind-flow'),
      windCitySelector: document.getElementById('windCitySelector'),
      windForecastHorizon: document.getElementById('windForecastHorizon'),
      windRefreshBtn: document.getElementById('windRefreshBtn'),
      windStatSpeed: document.getElementById('windStatSpeed'),
      windStatSpeedTag: document.getElementById('windStatSpeedTag'),
      windStatMeanSpeed: document.getElementById('windStatMeanSpeed'),
      windStatAngle: document.getElementById('windStatAngle'),
      windStatCardinal: document.getElementById('windStatCardinal'),
      windStatAngleFull: document.getElementById('windStatAngleFull'),
      windStatVentilation: document.getElementById('windStatVentilation'),
      windStatVentilationPill: document.getElementById('windStatVentilationPill'),
      windStatVentilationDesc: document.getElementById('windStatVentilationDesc'),
      windStatAnomalyCount: document.getElementById('windStatAnomalyCount'),
      windStatAnomalyPill: document.getElementById('windStatAnomalyPill'),
      windCompassNeedle: document.getElementById('windCompassNeedle'),
      hudCompassDeg: document.getElementById('hudCompassDeg'),
      hudCompassCard: document.getElementById('hudCompassCard'),
      hudCompassSpeed: document.getElementById('hudCompassSpeed'),
      windVectorU: document.getElementById('windVectorU'),
      windVectorV: document.getElementById('windVectorV'),
      windAdvisoryBanner: document.getElementById('windAdvisoryBanner'),
      windAdvisoryIcon: document.getElementById('windAdvisoryIcon'),
      windAdvisoryTitle: document.getElementById('windAdvisoryTitle'),
      windAdvisoryBody: document.getElementById('windAdvisoryBody'),
      canvasWindForecast: document.getElementById('canvasWindForecast'),
      windForecastStepsRow: document.getElementById('windForecastStepsRow'),
      windModelArch: document.getElementById('windModelArch'),
      windModelRmse: document.getElementById('windModelRmse'),
      statStagnationCount: document.getElementById('statStagnationCount'),
      statGustCount: document.getElementById('statGustCount'),
      statShearCount: document.getElementById('statShearCount'),
      badgeCountAll: document.getElementById('badgeCountAll'),
      badgeCountStag: document.getElementById('badgeCountStag'),
      badgeCountGust: document.getElementById('badgeCountGust'),
      badgeCountShear: document.getElementById('badgeCountShear'),
      windAnomalyFeed: document.getElementById('windAnomalyFeed'),

      // Notification Center
      notifCenterWrap: document.getElementById('notifCenterWrap'),
      notifBellBtn: document.getElementById('notifBellBtn'),
      notifUnreadBadge: document.getElementById('notifUnreadBadge'),
      notifPopoverPanel: document.getElementById('notifPopoverPanel'),
      notifActiveCountTag: document.getElementById('notifActiveCountTag'),
      notifListContainer: document.getElementById('notifListContainer'),
      alertPreferencesBtn: document.getElementById('alertPreferencesBtn'),
      markAllReadBtn: document.getElementById('markAllReadBtn'),

      // Simulator Map
      simulatorMap: document.getElementById('simulatorMap'),
      simHazardBadge: document.getElementById('simHazardBadge'),
      simWindVectorBadge: document.getElementById('simWindVectorBadge'),
      simPlumeEtaCapsule: document.getElementById('simPlumeEtaCapsule'),
      simPlumeEtaText: document.getElementById('simPlumeEtaText'),

      // Prediction Verification
      predictionVerifyCard: document.getElementById('predictionVerifyCard'),
      verifyPredAqi: document.getElementById('verifyPredAqi'),
      verifyPredPm25: document.getElementById('verifyPredPm25'),
      verifyCurrentLoc: document.getElementById('verifyCurrentLoc'),
      verifyHorizonToggle: document.getElementById('verifyHorizonToggle'),
      verifyTimestamp: document.getElementById('verifyTimestamp'),
      verifyBtnGroup: document.getElementById('verifyBtnGroup'),
      btnVerifyYes: document.getElementById('btnVerifyYes'),
      btnVerifyNo: document.getElementById('btnVerifyNo'),
      verifySuccessBanner: document.getElementById('verifySuccessBanner'),
      verifyDiscrepancySection: document.getElementById('verifyDiscrepancySection'),
      discrepancyReasons: document.getElementById('discrepancyReasons'),
      otherReasonInputWrap: document.getElementById('otherReasonInputWrap'),
      verifyOtherText: document.getElementById('verifyOtherText'),
      submitDiscrepancyBtn: document.getElementById('submitDiscrepancyBtn'),
      cancelDiscrepancyBtn: document.getElementById('cancelDiscrepancyBtn'),
      verifyReportedBanner: document.getElementById('verifyReportedBanner'),
      agreementPctText: document.getElementById('agreementPctText'),
      agreementProgressFill: document.getElementById('agreementProgressFill'),
      agreementDetailsText: document.getElementById('agreementDetailsText'),

      // Fire Alert & Ground Verification
      fireSmokeCard: document.getElementById('fireSmokeCard'),
      fireStatusPill: document.getElementById('fireStatusPill'),
      fireConfidenceScoreText: document.getElementById('fireConfidenceScoreText'),
      fireConfidenceStatusDesc: document.getElementById('fireConfidenceStatusDesc'),
      fireConfidenceFill: document.getElementById('fireConfidenceFill'),
      signalSatelliteText: document.getElementById('signalSatelliteText'),
      signalAerosolText: document.getElementById('signalAerosolText'),
      signalWindText: document.getElementById('signalWindText'),
      signalGroundText: document.getElementById('signalGroundText'),
      fireVerifyBtnGroup: document.getElementById('fireVerifyBtnGroup'),
      btnFireYes: document.getElementById('btnFireYes'),
      btnFireNo: document.getElementById('btnFireNo'),
      fireDetailsPanel: document.getElementById('fireDetailsPanel'),
      fireDetailPills: document.getElementById('fireDetailPills'),
      submitFireDetailBtn: document.getElementById('submitFireDetailBtn'),
      cancelFireDetailBtn: document.getElementById('cancelFireDetailBtn'),
      fireFeedbackBanner: document.getElementById('fireFeedbackBanner'),
      fireFeedbackIcon: document.getElementById('fireFeedbackIcon'),
      fireFeedbackTitle: document.getElementById('fireFeedbackTitle'),
      fireFeedbackDesc: document.getElementById('fireFeedbackDesc'),

      // Alert Preferences Modal
      alertSettingsModal: document.getElementById('alertSettingsModal'),
      alertSettingsBackdrop: document.getElementById('alertSettingsBackdrop'),
      closeAlertSettingsBtn: document.getElementById('closeAlertSettingsBtn'),
      prefEnableAlerts: document.getElementById('prefEnableAlerts'),
      prefRadiusGroup: document.getElementById('prefRadiusGroup'),
      prefTypeFire: document.getElementById('prefTypeFire'),
      prefTypeSmoke: document.getElementById('prefTypeSmoke'),
      prefTypeAqi: document.getElementById('prefTypeAqi'),
      prefTypeDiscrepancy: document.getElementById('prefTypeDiscrepancy'),
      saveAlertPreferencesBtn: document.getElementById('saveAlertPreferencesBtn')
    };
  }

  // Toast notifications for authentication & gateway events
  let toastTimer = null;
  function showAuthToast(message, isError = false) {
    if (!els.authToast) return;
    if (toastTimer) clearTimeout(toastTimer);
    els.authToast.textContent = message;
    els.authToast.style.borderColor = isError ? 'var(--linear-red)' : 'var(--linear-accent)';
    els.authToast.style.color = isError ? '#ff8080' : 'var(--linear-text-main)';
    els.authToast.classList.remove('hidden');
    els.authToast.classList.add('show');
    toastTimer = setTimeout(() => {
      els.authToast.classList.remove('show');
      setTimeout(() => els.authToast.classList.add('hidden'), 300);
    }, 3200);
  }

  function attachEventListeners() {
    // 1. Auth Switcher Tabs (Sign In / Register)
    if (els.tabBtnSignIn && els.tabBtnRegister) {
      els.tabBtnSignIn.addEventListener('click', () => {
        els.tabBtnSignIn.classList.add('active');
        els.tabBtnRegister.classList.remove('active');
        if (els.loginForm) els.loginForm.classList.remove('hidden');
        if (els.registerForm) els.registerForm.classList.add('hidden');
      });

      els.tabBtnRegister.addEventListener('click', () => {
        els.tabBtnRegister.classList.add('active');
        els.tabBtnSignIn.classList.remove('active');
        if (els.loginForm) els.loginForm.classList.add('hidden');
        if (els.registerForm) els.registerForm.classList.remove('hidden');
      });
    }

    if (els.linkToRegister) {
      els.linkToRegister.addEventListener('click', () => {
        if (els.tabBtnRegister) els.tabBtnRegister.click();
      });
    }

    if (els.linkToLogin) {
      els.linkToLogin.addEventListener('click', () => {
        if (els.tabBtnSignIn) els.tabBtnSignIn.click();
      });
    }

    // 2. Password Visibility Toggle
    if (els.togglePassVisibilityBtn && els.loginPass) {
      els.togglePassVisibilityBtn.addEventListener('click', () => {
        const isPass = els.loginPass.getAttribute('type') === 'password';
        els.loginPass.setAttribute('type', isPass ? 'text' : 'password');
        els.togglePassVisibilityBtn.classList.toggle('active', !isPass);
      });
    }

    // 3. Live Password Strength Meter for Registration
    if (els.regPass && els.passStrengthFill && els.passStrengthText) {
      els.regPass.addEventListener('input', (e) => {
        const val = e.target.value;
        let score = 0;
        if (val.length >= 6) score++;
        if (val.length >= 8) score++;
        if (/[A-Z]/.test(val) || /[0-9]/.test(val)) score++;
        if (/[^A-Za-z0-9]/.test(val)) score++;

        if (val.length === 0) {
          els.passStrengthFill.style.width = '0%';
          els.passStrengthFill.style.backgroundColor = 'transparent';
          els.passStrengthText.textContent = 'Minimum 6-8 chars with mixed cases';
          els.passStrengthText.style.color = 'var(--linear-text-dim)';
        } else if (score <= 1) {
          els.passStrengthFill.style.width = '25%';
          els.passStrengthFill.style.backgroundColor = 'var(--linear-red)';
          els.passStrengthText.textContent = 'Weak passkey - add numbers or symbols';
          els.passStrengthText.style.color = 'var(--linear-red)';
        } else if (score === 2) {
          els.passStrengthFill.style.width = '50%';
          els.passStrengthFill.style.backgroundColor = 'var(--linear-amber)';
          els.passStrengthText.textContent = 'Moderate security - add symbols & upper cases';
          els.passStrengthText.style.color = 'var(--linear-amber)';
        } else if (score === 3) {
          els.passStrengthFill.style.width = '75%';
          els.passStrengthFill.style.backgroundColor = '#38bdf8';
          els.passStrengthText.textContent = 'Strong telemetry passkey';
          els.passStrengthText.style.color = '#38bdf8';
        } else {
          els.passStrengthFill.style.width = '100%';
          els.passStrengthFill.style.backgroundColor = 'var(--linear-green)';
          els.passStrengthText.textContent = 'Maximum encryption standard verified';
          els.passStrengthText.style.color = 'var(--linear-green)';
        }
      });
    }

    // 4. Sign In Form Submit (Real Backend API + Local Resilience)
    if (els.loginForm) {
      els.loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = (els.loginEmail?.value || '').trim();
        const password = (els.loginPass?.value || '').trim();
        const role = els.loginRole?.options[els.loginRole.selectedIndex]?.text || 'Field Environmental Researcher';

        if (!email) {
          showAuthToast('Please enter an operator email identifier', true);
          return;
        }

        const submitBtn = els.loginSubmitBtn || els.loginForm.querySelector('button[type="submit"]');
        const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span>Verifying Credentials...</span>';
        }

        try {
          const resp = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, role })
          });
          const data = await resp.json();

          if (!resp.ok || !data.success) {
            showAuthToast(data.message || 'Authentication failed. Please check passkey.', true);
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = origBtnHtml;
            }
            return;
          }

          state.currentUser = data.user;
          if (els.rememberMe && els.rememberMe.checked) {
            localStorage.setItem('vayudrishti_user', JSON.stringify(data.user));
          }
          showAuthToast(`Access Granted: Welcome, ${data.user.name || data.user.email}`);
          setTimeout(() => handleSuccessfulLogin(), 300);
        } catch (err) {
          // Local fallback in case of disconnected network
          const initials = email.substring(0, 2).toUpperCase();
          state.currentUser = { email, name: email.split('@')[0], role, avatar: initials };
          if (els.rememberMe && els.rememberMe.checked) {
            localStorage.setItem('vayudrishti_user', JSON.stringify(state.currentUser));
          }
          showAuthToast(`Connected (Offline Mode): Welcome, ${state.currentUser.name}`);
          setTimeout(() => handleSuccessfulLogin(), 300);
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnHtml;
          }
        }
      });
    }

    // 5. Create Account / Register Form Submit (Real Backend API + Local Resilience)
    if (els.registerForm) {
      els.registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = (els.regName?.value || '').trim();
        const email = (els.regEmail?.value || '').trim();
        const password = (els.regPass?.value || '').trim();
        const role = els.regRole?.options[els.regRole.selectedIndex]?.text || 'Field Environmental Researcher';

        if (!name || !email) {
          showAuthToast('Operator name and institutional email are required', true);
          return;
        }

        if (password.length < 6) {
          showAuthToast('Passkey must be at least 6 characters long', true);
          return;
        }

        const submitBtn = els.regSubmitBtn || els.registerForm.querySelector('button[type="submit"]');
        const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span>Creating Operator Profile...</span>';
        }

        try {
          const resp = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password, role })
          });
          const data = await resp.json();

          if (!resp.ok || !data.success) {
            showAuthToast(data.message || 'Failed to create profile. Email may exist.', true);
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = origBtnHtml;
            }
            return;
          }

          state.currentUser = data.user;
          localStorage.setItem('vayudrishti_user', JSON.stringify(data.user));
          showAuthToast(`Profile Created! Welcome, ${data.user.name}`);
          setTimeout(() => handleSuccessfulLogin(), 400);
        } catch (err) {
          const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase() || 'OP';
          state.currentUser = { email, name, role, avatar: initials };
          localStorage.setItem('vayudrishti_user', JSON.stringify(state.currentUser));
          showAuthToast(`Profile Initialized (Local Mode): Welcome, ${name}`);
          setTimeout(() => handleSuccessfulLogin(), 400);
        } finally {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origBtnHtml;
          }
        }
      });
    }

    // 6. Fast SSO Sign-In (Google & Gov)
    if (els.ssoGoogleBtn) {
      els.ssoGoogleBtn.addEventListener('click', () => {
        state.currentUser = {
          name: 'Google Operator',
          email: 'google.auth@vayudrishti.ai',
          role: 'Field Environmental Researcher',
          avatar: 'GW'
        };
        sessionStorage.setItem('vayudrishti_active_session', 'true');
        localStorage.setItem('vayudrishti_user', JSON.stringify(state.currentUser));
        showAuthToast('Connected via Google Workspace Single Sign-On');
        setTimeout(() => handleSuccessfulLogin(), 300);
      });
    }
    if (els.ssoGovBtn) {
      els.ssoGovBtn.addEventListener('click', () => {
        state.currentUser = {
          name: 'NIC Officer',
          email: 'officer@nic.gov.in',
          role: 'Chief Atmospheric Director',
          avatar: 'NIC'
        };
        sessionStorage.setItem('vayudrishti_active_session', 'true');
        localStorage.setItem('vayudrishti_user', JSON.stringify(state.currentUser));
        showAuthToast('Authenticated via National Informatics Centre (NIC)');
        setTimeout(() => handleSuccessfulLogin(), 300);
      });
    }

    // 7. 1-Click Instant Demo Personas
    [els.personaBtn1, els.personaBtn2, els.personaBtn3].forEach(btn => {
      if (btn) {
        btn.addEventListener('click', async () => {
          const email = btn.getAttribute('data-email');
          const role = btn.getAttribute('data-role');
          const name = btn.querySelector('.persona-name')?.textContent || 'Operator';
          
          try {
            const resp = await fetch('/api/auth/login', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ email, password: 'VayuPass@2026', role })
            });
            const data = await resp.json();
            if (data.success && data.user) {
              state.currentUser = data.user;
            } else {
              const avatar = name.includes('Sharma') ? 'DS' : (name.includes('Policy') ? 'PC' : 'DV');
              state.currentUser = { email, name, role, avatar };
            }
          } catch (e) {
            const avatar = name.includes('Sharma') ? 'DS' : (name.includes('Policy') ? 'PC' : 'DV');
            state.currentUser = { email, name, role, avatar };
          }

          sessionStorage.setItem('vayudrishti_active_session', 'true');
          localStorage.setItem('vayudrishti_user', JSON.stringify(state.currentUser));
          showAuthToast(`Authenticated as ${state.currentUser.name} (${state.currentUser.role})`);
          setTimeout(() => handleSuccessfulLogin(), 250);
        });
      }
    });

    // 8. Forgot Passkey Modal Logic
    if (els.forgotPassLink) {
      els.forgotPassLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (els.forgotPassModal) els.forgotPassModal.classList.remove('hidden');
      });
    }
    const closeForgotModal = () => {
      if (els.forgotPassModal) els.forgotPassModal.classList.add('hidden');
    };
    if (els.closeForgotModalBtn) els.closeForgotModalBtn.addEventListener('click', closeForgotModal);
    if (els.forgotModalBackdrop) els.forgotModalBackdrop.addEventListener('click', closeForgotModal);

    if (els.sendRecoveryBtn) {
      els.sendRecoveryBtn.addEventListener('click', () => {
        const email = els.recoveryEmail?.value || 'researcher@aerotrace.gov';
        closeForgotModal();
        showAuthToast(`Security token dispatched to ${email}`);
      });
    }

    // 9. Legacy Quick Demo Entry
    if (els.demoQuickLoginBtn) {
      els.demoQuickLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        state.currentUser = {
          name: 'Demo Researcher',
          email: 'demo.researcher@vayudrishti.ai',
          role: 'Field Environmental Researcher',
          avatar: 'FR'
        };
        sessionStorage.setItem('vayudrishti_active_session', 'true');
        showAuthToast('Demo Researcher mode initialized');
        setTimeout(() => handleSuccessfulLogin(), 250);
      });
    }

    // 10. Logout Button
    if (els.logoutBtn) {
      els.logoutBtn.addEventListener('click', () => {
        sessionStorage.removeItem('vayudrishti_active_session');
        localStorage.removeItem('vayudrishti_user');
        localStorage.removeItem('aerotrace_user');
        state.isLoggedIn = false;
        if (radarAnimId) cancelAnimationFrame(radarAnimId);
        showLoginPage();
        showAuthToast('Operator logged out securely');
      });
    }

    // Nav Brand Logo
    els.navBrandLogo.addEventListener('click', () => {
      switchPage('page-dashboard');
    });

    // Navigation Tabs
    els.navTabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const target = tab.getAttribute('data-target');
        switchPage(target);
      });
    });

    // Global City Selector
    els.globalCitySelector.addEventListener('change', (e) => {
      const val = e.target.value;
      if (val === 'custom') {
        openCustomLocationModal();
      } else if (PRESETS[val]) {
        state.currentCityKey = val;
        const p = PRESETS[val];
        state.location = { lat: p.lat, lng: p.lng, name: p.name };
        els.routeOriginInput.value = p.origin;
        els.routeDestInput.value = p.dest;
        fetchAirQuality(p.lat, p.lng);
      }
    });

    // Modal
    els.closeModalBtn.addEventListener('click', closeCustomLocationModal);
    els.modalBackdrop.addEventListener('click', closeCustomLocationModal);
    els.applyCustomCoordsBtn.addEventListener('click', () => {
      const lat = parseFloat(els.customLatInput.value);
      const lng = parseFloat(els.customLngInput.value);
      if (!isNaN(lat) && !isNaN(lng)) {
        state.location = { lat, lng, name: `Custom (${lat.toFixed(4)}, ${lng.toFixed(4)})` };
        closeCustomLocationModal();
        fetchAirQuality(lat, lng);
      }
    });

    // Map Controls
    if (els.layerSatBtn) els.layerSatBtn.addEventListener('click', () => setMapLayer('SATELLITE'));
    if (els.layerDarkBtn) els.layerDarkBtn.addEventListener('click', () => setMapLayer('DARK'));
    if (els.layerRadarBtn) els.layerRadarBtn.addEventListener('click', () => setMapLayer('RADAR'));
    els.toggle3dBtn.addEventListener('click', toggle3dMap);
    els.centerMapBtn.addEventListener('click', centerMapOnCurrent);

    // Investigation
    els.investigateBtn.addEventListener('click', runPollutionInvestigation);

    // Routes
    els.calculateRouteBtn.addEventListener('click', runRouteExposureCalculation);

    // Simulator Sliders
    els.trafficSlider.addEventListener('input', handleSimulatorInput);
    els.industrialSlider.addEventListener('input', handleSimulatorInput);
    els.burningSlider.addEventListener('input', handleSimulatorInput);

    // Chat
    els.sendChatBtn.addEventListener('click', sendChatMessage);
    els.chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') sendChatMessage();
    });

    // Clear Chat
    els.clearChatBtn.addEventListener('click', () => {
      els.chatMessages.innerHTML = '';
      appendChatMessage('Vayudrishti Intelligence Core', 'Telemetry stream reset. Calibrated for ' + state.location.name + '. Ask any environmental question.', 'bot-message');
    });

    // Quick Prompt Chips in Studio
    document.querySelectorAll('.sketch-chip').forEach(btn => {
      btn.addEventListener('click', () => {
        const query = btn.getAttribute('data-query');
        els.chatInput.value = query;
        sendChatMessage();
      });
    });

    // Voice TTS Toggle
    els.ttsToggleBtn.addEventListener('click', () => {
      state.ttsEnabled = !state.ttsEnabled;
      els.ttsToggleBtn.textContent = state.ttsEnabled ? 'Voice: On' : 'Voice: Off';
      els.ttsToggleBtn.style.color = state.ttsEnabled ? '#4ade80' : '';
      if (state.ttsEnabled) speakText('Voice telemetry readout active.');
    });

    // Window Resize Handler for Canvas
    window.addEventListener('resize', () => {
      if (state.currentPage === 'page-dashboard') {
        renderMap();
      } else if (state.currentPage === 'page-graphs-hub') {
        renderAllGraphs();
      } else if (state.currentPage === 'page-wind-flow') {
        renderWindForecastChart();
      }
    });

    // Wind Dynamics & Anomaly Radar Controls
    if (els.windCitySelector) {
      els.windCitySelector.addEventListener('change', (e) => {
        state.windData.currentCity = e.target.value;
        loadWindAnalytics();
      });
    }

    if (els.windForecastHorizon) {
      els.windForecastHorizon.addEventListener('change', (e) => {
        state.windData.horizonMonths = parseInt(e.target.value, 10);
        loadWindAnalytics();
      });
    }

    if (els.windRefreshBtn) {
      els.windRefreshBtn.addEventListener('click', () => {
        loadWindAnalytics();
        showAuthToast('Re-running wind predictive spline & anomaly models...');
      });
    }

    // Horizon Quick Pills (3M, 6M, 12M)
    document.querySelectorAll('.horizon-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('.horizon-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        const months = parseInt(pill.getAttribute('data-months'), 10);
        state.windData.horizonMonths = months;
        if (els.windForecastHorizon) els.windForecastHorizon.value = months;
        loadWindAnalytics();
      });
    });

    // Anomaly Filter Tabs (ALL, STAGNATION, GUST, SHEAR)
    document.querySelectorAll('.filter-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.windData.activeAnomalyFilter = tab.getAttribute('data-type') || 'ALL';
        renderAnomalyFeed();
      });
    });

    // Forecast Canvas Hover Interaction
    if (els.canvasWindForecast) {
      els.canvasWindForecast.addEventListener('mousemove', handleForecastCanvasHover);
      els.canvasWindForecast.addEventListener('mouseleave', () => {
        state.windData.hoverPoint = null;
        renderWindForecastChart();
      });
    }

    // 11. Notification Center Popover & Actions
    if (els.notifBellBtn) {
      els.notifBellBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (els.notifPopoverPanel) {
          els.notifPopoverPanel.classList.toggle('hidden');
        }
      });
    }

    // Close notification popover when clicking anywhere else
    document.addEventListener('click', (e) => {
      if (els.notifPopoverPanel && !els.notifPopoverPanel.classList.contains('hidden')) {
        if (!els.notifPopoverPanel.contains(e.target) && !els.notifBellBtn.contains(e.target)) {
          els.notifPopoverPanel.classList.add('hidden');
        }
      }
    });

    if (els.markAllReadBtn) {
      els.markAllReadBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (els.notifUnreadBadge) els.notifUnreadBadge.style.display = 'none';
        if (els.notifActiveCountTag) els.notifActiveCountTag.textContent = '0 Unread';
        showAuthToast('All environmental notifications marked as read');
        try {
          await fetch('/api/notifications/read', { method: 'POST' });
        } catch (err) {}
      });
    }

    // 12. Alert Preferences Modal
    if (els.alertPreferencesBtn) {
      els.alertPreferencesBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (els.notifPopoverPanel) els.notifPopoverPanel.classList.add('hidden');
        if (els.alertSettingsModal) els.alertSettingsModal.classList.remove('hidden');
      });
    }

    const closeAlertSettings = () => {
      if (els.alertSettingsModal) els.alertSettingsModal.classList.add('hidden');
    };
    if (els.closeAlertSettingsBtn) els.closeAlertSettingsBtn.addEventListener('click', closeAlertSettings);
    if (els.alertSettingsBackdrop) els.alertSettingsBackdrop.addEventListener('click', closeAlertSettings);

    // Radius Selection Pills
    if (els.prefRadiusGroup) {
      els.prefRadiusGroup.querySelectorAll('.radius-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          els.prefRadiusGroup.querySelectorAll('.radius-pill').forEach(p => p.classList.remove('active'));
          pill.classList.add('active');
        });
      });
    }

    // Save Alert Preferences
    if (els.saveAlertPreferencesBtn) {
      els.saveAlertPreferencesBtn.addEventListener('click', async () => {
        const activeRadiusPill = els.prefRadiusGroup?.querySelector('.radius-pill.active');
        const radiusKm = activeRadiusPill ? parseInt(activeRadiusPill.getAttribute('data-radius'), 10) : 5;
        const enabled = els.prefEnableAlerts ? els.prefEnableAlerts.checked : true;
        const preferences = {
          fireAlert: els.prefTypeFire ? els.prefTypeFire.checked : true,
          smokeAlert: els.prefTypeSmoke ? els.prefTypeSmoke.checked : true,
          aqiAlert: els.prefTypeAqi ? els.prefTypeAqi.checked : true,
          discrepancyAlert: els.prefTypeDiscrepancy ? els.prefTypeDiscrepancy.checked : true
        };

        state.alertPreferences = { enabled, radiusKm, preferences };
        closeAlertSettings();

        try {
          await fetch('/api/notifications/subscribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled, radiusKm, preferences })
          });
          showAuthToast(`Alert settings updated: ${radiusKm} km radius active`);
          loadNotifications();
        } catch (err) {
          showAuthToast(`Preferences applied locally: ${radiusKm} km`);
        }
      });
    }

    // 13. Prediction Verification Card Handlers
    // Horizon toggle (1h / 2h)
    if (els.verifyHorizonToggle) {
      els.verifyHorizonToggle.querySelectorAll('.mini-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          els.verifyHorizonToggle.querySelectorAll('.mini-pill').forEach(p => p.classList.remove('active'));
          pill.classList.add('active');
          state.verificationData.activeHorizon = pill.getAttribute('data-horizon') || '1h';
          loadPredictionVerification();
        });
      });
    }

    // YES Button
    if (els.btnVerifyYes) {
      els.btnVerifyYes.addEventListener('click', () => {
        submitAqiVerification('confirmed');
      });
    }

    // NO Button
    if (els.btnVerifyNo) {
      els.btnVerifyNo.addEventListener('click', () => {
        if (els.verifyDiscrepancySection) {
          els.verifyDiscrepancySection.classList.remove('hidden');
          els.verifyBtnGroup.classList.add('hidden');
        }
      });
    }

    // Discrepancy Reason Pills
    if (els.discrepancyReasons) {
      els.discrepancyReasons.querySelectorAll('.reason-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          els.discrepancyReasons.querySelectorAll('.reason-pill').forEach(p => p.classList.remove('selected'));
          pill.classList.add('selected');
          const reason = pill.getAttribute('data-reason');
          state.verificationData.disputedReason = reason;

          if (reason === 'other') {
            if (els.otherReasonInputWrap) els.otherReasonInputWrap.classList.remove('hidden');
            if (els.verifyOtherText) els.verifyOtherText.focus();
          } else {
            if (els.otherReasonInputWrap) els.otherReasonInputWrap.classList.add('hidden');
          }

          if (els.submitDiscrepancyBtn) els.submitDiscrepancyBtn.disabled = false;
        });
      });
    }

    // Discrepancy Submit
    if (els.submitDiscrepancyBtn) {
      els.submitDiscrepancyBtn.addEventListener('click', () => {
        const otherText = els.verifyOtherText?.value?.trim() || null;
        submitAqiVerification('disputed', state.verificationData.disputedReason || 'polluted', otherText);
      });
    }

    // Discrepancy Cancel
    if (els.cancelDiscrepancyBtn) {
      els.cancelDiscrepancyBtn.addEventListener('click', () => {
        if (els.verifyDiscrepancySection) els.verifyDiscrepancySection.classList.add('hidden');
        if (els.verifyBtnGroup) els.verifyBtnGroup.classList.remove('hidden');
      });
    }

    // 14. Fire Alert Ground Truth Verification Handlers
    // Fire YES
    if (els.btnFireYes) {
      els.btnFireYes.addEventListener('click', () => {
        if (els.fireDetailsPanel) {
          els.fireDetailsPanel.classList.remove('hidden');
          els.fireVerifyBtnGroup.classList.add('hidden');
        }
      });
    }

    // Fire NO
    if (els.btnFireNo) {
      els.btnFireNo.addEventListener('click', () => {
        submitFireVerification(false, 'not_observed_locally');
      });
    }

    // Fire Detail Pills
    if (els.fireDetailPills) {
      els.fireDetailPills.querySelectorAll('.reason-pill').forEach(pill => {
        pill.addEventListener('click', () => {
          els.fireDetailPills.querySelectorAll('.reason-pill').forEach(p => p.classList.remove('selected'));
          pill.classList.add('selected');
          state.verificationData.userObservedDetails = pill.getAttribute('data-detail');
          if (els.submitFireDetailBtn) els.submitFireDetailBtn.disabled = false;
        });
      });
    }

    // Fire Detail Submit
    if (els.submitFireDetailBtn) {
      els.submitFireDetailBtn.addEventListener('click', () => {
        submitFireVerification(true, state.verificationData.userObservedDetails || 'heavy_smoke');
      });
    }

    // Fire Detail Cancel
    if (els.cancelFireDetailBtn) {
      els.cancelFireDetailBtn.addEventListener('click', () => {
        if (els.fireDetailsPanel) els.fireDetailsPanel.classList.add('hidden');
        if (els.fireVerifyBtnGroup) els.fireVerifyBtnGroup.classList.remove('hidden');
      });
    }
  }

  function handleSuccessfulLogin(isSilent = false) {
    state.isLoggedIn = true;
    sessionStorage.setItem('vayudrishti_active_session', 'true');

    const user = state.currentUser || {};
    const name = user.name || (user.email ? user.email.split('@')[0] : 'Operator');
    const role = user.role || 'Field Environmental Researcher';
    const avatar = user.avatar || (name ? name.substring(0, 2).toUpperCase() : 'OP');

    if (els.operatorAvatar) {
      els.operatorAvatar.textContent = avatar;
      els.operatorAvatar.title = `${name} (${role})`;
    }
    if (els.operatorName) {
      els.operatorName.textContent = name;
    }
    if (els.operatorRole) {
      els.operatorRole.textContent = role;
    }

    if (els.pageLogin) {
      els.pageLogin.classList.remove('active');
      els.pageLogin.classList.add('hidden');
    }
    if (els.appShell) {
      els.appShell.classList.remove('hidden');
      els.appShell.classList.add('active');
    }

    switchPage('page-dashboard');
    fetchAirQuality(state.location.lat, state.location.lng);
    loadNotifications();
    initEnvironmentalPolling();

    if (!isSilent) {
      showAuthToast(`Session Active: Welcome, ${name}`);
    }
  }

  function switchPage(targetPageId) {
    state.currentPage = targetPageId;

    // Update Nav Tabs
    els.navTabs.forEach(tab => {
      if (tab.getAttribute('data-target') === targetPageId) {
        tab.classList.add('active');
      } else {
        tab.classList.remove('active');
      }
    });

    // Update View Containers
    els.pageViews.forEach(view => {
      if (view.id === targetPageId) {
        view.classList.add('active');
      } else {
        view.classList.remove('active');
      }
    });

    if (targetPageId === 'page-dashboard') {
      initMap();
    } else if (targetPageId === 'page-routes-simulator') {
      setTimeout(() => {
        initSimulatorMap();
        loadPredictionVerification();
      }, 60);
    } else if (targetPageId === 'page-graphs-hub') {
      setTimeout(() => renderAllGraphs(), 50);
    } else if (targetPageId === 'page-wind-flow') {
      if (!state.windData.history || state.windData.history.length === 0) {
        loadWindAnalytics();
      } else {
        setTimeout(() => renderWindForecastChart(), 50);
      }
    }
  }

  function openCustomLocationModal() {
    els.customLocModal.classList.remove('hidden');
    els.customLatInput.value = state.location.lat;
    els.customLngInput.value = state.location.lng;
  }

  function closeCustomLocationModal() {
    els.customLocModal.classList.add('hidden');
    if (state.currentCityKey !== 'custom') {
      els.globalCitySelector.value = state.currentCityKey;
    }
  }

  // Load Config
  async function loadServerConfig() {
    try {
      const resp = await fetch('/api/config');
      const data = await resp.json();
      state.config = data;
      if (data.hasMapsKey) {
        els.footerGoogleText.textContent = 'Google Maps Live';
        els.footerGoogleText.className = 'text-success';
      }
      if (data.hasGeminiKey) {
        els.aiAssistantBadge.textContent = 'GEMINI PRO';
      }
    } catch (e) {
      console.warn('Config fetch error, using fallback');
    }
  }

  // Check Python Health
  async function checkPythonHealth() {
    try {
      const resp = await fetch('/api/python-health');
      const data = await resp.json();
      if (data.success && data.status === 'CONNECTED') {
        els.footerPythonText.textContent = 'Online (FastAPI)';
        els.footerPythonText.className = 'text-success';
      } else {
        els.footerPythonText.textContent = 'Node Fallback';
        els.footerPythonText.className = 'text-warning';
      }
    } catch (e) {
      els.footerPythonText.textContent = 'Node Fallback';
      els.footerPythonText.className = 'text-warning';
    }
  }

  // Fetch Air Quality
  async function fetchAirQuality(lat, lng) {
    try {
      const resp = await fetch(`/api/air-quality?lat=${lat}&lng=${lng}`);
      const data = await resp.json();
      state.aqiData = data;

      updateMetricUi(data);
      await fetchRiskScore(data.aqi, data.pm25, data.pm10);
      updateAlerts(data);
      runSimulatorScenario();
      renderMap();

      loadPredictionVerification();
      updateSimulatorMapOverlays();
      loadNotifications();

      if (state.currentPage === 'page-graphs-hub') {
        renderAllGraphs();
      }

      if (els.aiModelStatusText) {
        els.aiModelStatusText.textContent = `Calibrated with Live Telemetry (${state.location.name})`;
      }
    } catch (err) {
      console.error('Air quality fetch error:', err);
    }
  }

  function updateMetricUi(data) {
    const aqi = data.aqi || 184;
    const pm25 = data.pm25 || 112;
    const pm10 = data.pm10 || 178;
    const cat = data.category || 'Unhealthy';
    const isLive = data.status === 'LIVE';

    els.aqiValue.textContent = aqi;
    els.aqiBadge.textContent = cat.toUpperCase();
    els.pm25Value.textContent = pm25;
    els.pm10Value.textContent = pm10;
    els.aqiSourceText.textContent = data.source || (isLive ? 'Google Maps Air Quality API' : 'DEMO DATA');
    els.aqiUpdatedText.textContent = new Date().toLocaleTimeString();

    if (isLive) {
      els.globalDataStatusText.textContent = 'LIVE ACTIVE';
      if (els.globalStatusCapsule) els.globalStatusCapsule.classList.add('live-badge');
    } else {
      els.globalDataStatusText.textContent = 'DEMO ACTIVE';
      if (els.globalStatusCapsule) els.globalStatusCapsule.classList.remove('live-badge');
    }

    const meterPct = Math.min(100, Math.max(5, (aqi / 300) * 100));
    els.aqiMeterFill.style.width = meterPct + '%';

    const exceedFactor = (pm25 / 15.0).toFixed(1);
    els.pm25Exceed.textContent = exceedFactor + 'x Limit';

    if (aqi > 200) {
      els.aqiBadge.className = 'status-pill status-danger';
    } else if (aqi > 100) {
      els.aqiBadge.className = 'status-pill status-unhealthy';
    } else if (aqi > 50) {
      els.aqiBadge.className = 'status-pill status-warning';
    } else {
      els.aqiBadge.className = 'status-pill status-success';
    }

    els.simCurrentAqi.textContent = aqi;
  }

  async function fetchRiskScore(aqi, pm25, pm10) {
    try {
      const resp = await fetch('/api/risk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aqi, pm25, pm10, trend: 'STABLE' })
      });
      const res = await resp.json();
      if (res.success && res.data) {
        state.riskData = res.data;
        els.riskScoreValue.textContent = res.data.score;
        els.riskLevelBadge.textContent = res.data.level + ' RISK';
        els.riskAdvisoryText.textContent = res.data.advisory;
        
        if (res.data.level === 'HIGH' || res.data.level === 'CRITICAL') {
          els.riskLevelBadge.className = 'status-pill status-danger';
        } else if (res.data.level === 'MODERATE') {
          els.riskLevelBadge.className = 'status-pill status-warning';
        } else {
          els.riskLevelBadge.className = 'status-pill status-success';
        }
      }
    } catch (e) {
      console.warn('Risk score error:', e);
    }
  }

  function updateAlerts(data) {
    const aqi = data.aqi || 184;
    const pm25 = data.pm25 || 112;
    const cityName = state.location.name;

    let html = '';

    if (aqi >= 200) {
      html += `
        <div class="alert-card-linear crit">
          <div class="stat-header">
            <span class="status-pill status-danger">CRITICAL HAZARD</span>
          </div>
          <h4>Severe Atmospheric Inversion in ${cityName}</h4>
          <p>AQI index reached ${aqi}. Immediate health warnings across all demographics. Vigorous outdoor exertion is prohibited.</p>
        </div>
      `;
    } else if (aqi >= 150) {
      html += `
        <div class="alert-card-linear high">
          <div class="stat-header">
            <span class="status-pill status-warning">HIGH RISK (${aqi})</span>
          </div>
          <h4>Unhealthy Urban Air Quality</h4>
          <p>Elevated aerosol optical density across urban canopy. Sensitive groups face acute respiratory distress.</p>
        </div>
      `;
    }

    if (pm25 > 90) {
      html += `
        <div class="alert-card-linear high">
          <div class="stat-header">
            <span class="status-pill status-danger">PM2.5 EXCEEDANCE</span>
          </div>
          <h4>Combustion Aerosol Density (${pm25} µg/m³)</h4>
          <p>Fine particulate load is ${(pm25/15).toFixed(1)}x above international safety standards. Wear N95 filtration outdoors.</p>
        </div>
      `;
    }

    html += `
      <div class="alert-card-linear warn">
        <div class="stat-header">
          <span class="status-pill status-lavender">TRANSIT ADVISORY</span>
        </div>
        <h4>Commute Exposure Warning</h4>
        <p>Direct arterial routes experience acute vehicular stagnation. Eco-Bypass green corridor recommended.</p>
      </div>
    `;

    els.alertsFeed.innerHTML = html;
  }

  // Investigation
  async function runPollutionInvestigation() {
    els.investigateBtn.disabled = true;
    els.investigateBtn.innerHTML = '<span>Analyzing Aerosols...</span>';

    try {
      const resp = await fetch('/api/investigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          aqi: state.aqiData.aqi,
          pm25: state.aqiData.pm25,
          pm10: state.aqiData.pm10,
          location: state.location
        })
      });

      const res = await resp.json();
      if (res.success && res.data) {
        const d = res.data;
        state.sources = d.sources || state.sources;

        let tVal = 72, iVal = 18, bVal = 10;
        d.sources.forEach(s => {
          const name = s.name.toLowerCase();
          if (name.includes('traffic') || name.includes('vehic')) tVal = s.contribution;
          if (name.includes('indust')) iVal = s.contribution;
          if (name.includes('burn')) bVal = s.contribution;
        });

        els.trafficPct.textContent = tVal + '%';
        els.trafficFill.style.width = tVal + '%';
        els.industrialPct.textContent = iVal + '%';
        els.industrialFill.style.width = iVal + '%';
        els.burningPct.textContent = bVal + '%';
        els.burningFill.style.width = bVal + '%';

        els.sourceConfidence.textContent = Math.round((d.confidence || 0.84) * 100) + '%';
        els.aiExplanationText.textContent = d.explanation;

        if (d.recommendations && d.recommendations.length > 0) {
          els.recommendationsList.innerHTML = d.recommendations.map(r => `<li>${r}</li>`).join('');
        }

        if (state.ttsEnabled) speakText(d.explanation);
      }
    } catch (err) {
      console.error('Investigation error:', err);
    } finally {
      els.investigateBtn.disabled = false;
      els.investigateBtn.innerHTML = '<span>Investigate Pollution</span>';
    }
  }

  // Route Exposure
  async function runRouteExposureCalculation() {
    const origin = els.routeOriginInput.value;
    const dest = els.routeDestInput.value;
    els.calculateRouteBtn.disabled = true;
    els.calculateRouteBtn.textContent = 'Computing...';

    try {
      const resp = await fetch('/api/route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ origin, destination: dest, base_aqi: state.aqiData.aqi })
      });
      const res = await resp.json();
      if (res.success && res.data) {
        const d = res.data;
        els.directDist.textContent = d.direct_route.distance_km;
        els.directDur.textContent = d.direct_route.duration_min;
        els.directExposure.textContent = d.direct_route.exposure_score;

        els.ecoDist.textContent = d.lower_exposure_route.distance_km;
        els.ecoDur.textContent = d.lower_exposure_route.duration_min;
        els.ecoExposure.textContent = d.lower_exposure_route.exposure_score;

        els.exposureReductionText.textContent = `${d.exposure_reduction_pct}% LOWER ESTIMATED EXPOSURE`;
        els.routeRecText.innerHTML = `${d.recommendation}`;

        if (state.ttsEnabled) speakText(d.recommendation);
      }
    } catch (e) {
      console.error('Route error:', e);
    } finally {
      els.calculateRouteBtn.disabled = false;
      els.calculateRouteBtn.textContent = 'Compute Exposure';
    }
  }

  // Simulator
  function handleSimulatorInput() {
    els.trafficSliderVal.textContent = els.trafficSlider.value + '%';
    els.industrialSliderVal.textContent = els.industrialSlider.value + '%';
    els.burningSliderVal.textContent = els.burningSlider.value + '%';
    runSimulatorScenario();
  }

  async function runSimulatorScenario() {
    const currentAqi = state.aqiData.aqi || 184;
    const tVal = parseFloat(els.trafficSlider.value);
    const iVal = parseFloat(els.industrialSlider.value);
    const bVal = parseFloat(els.burningSlider.value);

    try {
      const resp = await fetch('/api/intervention', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          current_aqi: currentAqi,
          traffic_reduction: tVal,
          industrial_reduction: iVal,
          open_burning_reduction: bVal,
          sources: state.sources
        })
      });
      const res = await resp.json();
      if (res.success && res.data) {
        const d = res.data;
        els.simProjectedAqi.textContent = d.projected_aqi;
        els.simReductionPct.textContent = `-${d.estimated_reduction_pct}%`;
        els.simProjCat.textContent = d.projected_category;
        
        if (d.insights && d.insights.length > 0) {
          els.simInsightsText.textContent = d.insights[0];
        } else {
          els.simInsightsText.textContent = `Cumulative policy intervention achieves a ${d.estimated_reduction_pct}% reduction in toxic particulate load.`;
        }
      }
    } catch (e) {
      console.warn('Simulation error:', e);
    }
  }

  // AI Assistant Chat
  async function sendChatMessage() {
    const msg = els.chatInput.value.trim();
    if (!msg) return;

    appendChatMessage(state.currentUser.role || 'RESEARCHER', msg, 'user-message');
    els.chatInput.value = '';

    const typingElem = appendChatMessage('Vayudrishti Intelligence Core', 'Processing atmospheric stoichiometry and telemetry context...', 'bot-message');

    try {
      const resp = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msg,
          context: {
            aqi: state.aqiData.aqi,
            pm25: state.aqiData.pm25,
            pm10: state.aqiData.pm10,
            locationName: state.location.name,
            category: state.aqiData.category,
            riskScore: state.riskData.score,
            riskLevel: state.riskData.level
          }
        })
      });

      const res = await resp.json();
      const reply = res.reply || 'Analysis complete for current operational sector.';
      
      typingElem.querySelector('.message-body').innerHTML = formatMarkdownText(reply);
      els.chatMessages.scrollTop = els.chatMessages.scrollHeight;

      if (state.ttsEnabled) {
        speakText(reply.replace(/[*#_•]/g, ''));
      }
    } catch (e) {
      typingElem.querySelector('.message-body').textContent = 'Environmental field gateway temporarily busy. Please retry shortly.';
    }
  }

  function appendChatMessage(sender, text, className) {
    const div = document.createElement('div');
    const isUser = className.includes('user');
    div.className = `chat-message ${isUser ? 'user-message' : 'bot-message'}`;

    const avatarSvg = isUser
      ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8a8f98" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`
      : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#5e6ad2" stroke-width="2"><rect x="3" y="11" width="18" height="10" rx="2"></rect><circle cx="12" cy="5" r="2"></circle><path d="M12 7v4"></path></svg>`;

    div.innerHTML = `
      <div class="message-avatar">${avatarSvg}</div>
      <div class="message-content">
        <div class="message-header">
          <span class="message-author">${sender.toUpperCase()}</span>
        </div>
        <div class="message-body">${formatMarkdownText(text)}</div>
      </div>
    `;
    els.chatMessages.appendChild(div);
    els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
    return div;
  }

  function formatMarkdownText(text) {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');
  }

  function speakText(text) {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  }

  // =========================================================================
  // GEOSPATIAL SATELLITE & TACTICAL RADAR ENGINE
  // =========================================================================
  function initMap() {
    if (state.config.hasMapsKey && typeof google !== 'undefined' && google.maps) {
      loadGoogleMaps();
    } else if (typeof L !== 'undefined') {
      loadLeafletMap();
    } else {
      renderDemoRadarMap();
    }
  }

  function loadLeafletMap() {
    state.mapMode = 'LEAFLET';
    if (radarAnimId) {
      cancelAnimationFrame(radarAnimId);
      radarAnimId = null;
    }

    // Reset container for Leaflet
    els.mapPanel.innerHTML = '<div id="leafletMapInner" style="width:100%;height:100%;"></div>';
    const innerContainer = document.getElementById('leafletMapInner');

    try {
      leafletMap = L.map(innerContainer, {
        center: [state.location.lat, state.location.lng],
        zoom: 12,
        zoomControl: true,
        attributionControl: false
      });

      // High-Resolution Earth Satellite Imagery (Matches exact user requirement)
      leafletSatLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19,
        attribution: 'Esri World Imagery'
      });

      // CartoDB Dark Matter Layer
      leafletDarkLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
        attribution: 'CartoDB Dark Matter'
      });

      // Apply initial layer (Satellite by default)
      if (activeMapType === 'DARK') {
        leafletDarkLayer.addTo(leafletMap);
        els.mapModeBadge.textContent = 'CARTO DARK';
        els.mapModeBadge.className = 'status-badge';
      } else {
        leafletSatLayer.addTo(leafletMap);
        els.mapModeBadge.textContent = 'SATELLITE LIVE';
        els.mapModeBadge.className = 'status-badge live-badge';
      }

      leafletMarkersGroup = L.layerGroup().addTo(leafletMap);
      updateLeafletOverlays();
      updateLayerButtonStates();

      // Ensure proper sizing after DOM render
      setTimeout(() => {
        if (leafletMap) leafletMap.invalidateSize();
      }, 100);

    } catch (err) {
      console.warn('Leaflet initialization failed, falling back to radar:', err);
      renderDemoRadarMap();
    }
  }

  function setMapLayer(type) {
    activeMapType = type;
    updateLayerButtonStates();

    if (type === 'RADAR') {
      state.mapMode = 'DEMO';
      if (leafletMap) {
        leafletMap.remove();
        leafletMap = null;
      }
      renderDemoRadarMap();
      els.mapModeBadge.textContent = 'TACTICAL RADAR';
      els.mapModeBadge.className = 'status-badge';
      return;
    }

    if (!leafletMap || state.mapMode !== 'LEAFLET') {
      loadLeafletMap();
    } else {
      if (type === 'SATELLITE') {
        if (leafletMap.hasLayer(leafletDarkLayer)) leafletMap.removeLayer(leafletDarkLayer);
        if (!leafletMap.hasLayer(leafletSatLayer)) leafletSatLayer.addTo(leafletMap);
        els.mapModeBadge.textContent = 'SATELLITE LIVE';
        els.mapModeBadge.className = 'status-badge live-badge';
      } else if (type === 'DARK') {
        if (leafletMap.hasLayer(leafletSatLayer)) leafletMap.removeLayer(leafletSatLayer);
        if (!leafletMap.hasLayer(leafletDarkLayer)) leafletDarkLayer.addTo(leafletMap);
        els.mapModeBadge.textContent = 'CARTO DARK';
        els.mapModeBadge.className = 'status-badge';
      }
    }
  }

  function updateLayerButtonStates() {
    if (els.layerSatBtn) els.layerSatBtn.classList.toggle('active', activeMapType === 'SATELLITE');
    if (els.layerDarkBtn) els.layerDarkBtn.classList.toggle('active', activeMapType === 'DARK');
    if (els.layerRadarBtn) els.layerRadarBtn.classList.toggle('active', activeMapType === 'RADAR');
  }

  function updateLeafletOverlays() {
    if (!leafletMap || !leafletMarkersGroup) return;
    leafletMarkersGroup.clearLayers();

    const lat = state.location.lat;
    const lng = state.location.lng;
    const aqi = state.aqiData.aqi || 184;

    // 1. Hotspot Core Buffer (Severe particulate concentration zone)
    L.circle([lat, lng], {
      color: '#ef4444',
      fillColor: '#ef4444',
      fillOpacity: 0.28,
      radius: 2000,
      weight: 2
    }).bindPopup(`<div style="font-size:12px;"><strong>🔥 Hotspot Core: ${state.location.name}</strong><br>AQI Level: <span style="color:#ef4444;font-weight:bold;">${aqi}</span><br>Status: Severe Inversion Zone</div>`).addTo(leafletMarkersGroup);

    // Stagnation Buffer
    L.circle([lat + 0.015, lng - 0.018], {
      color: '#f59e0b',
      fillColor: '#f59e0b',
      fillOpacity: 0.2,
      radius: 1400,
      weight: 1.5
    }).bindPopup(`<div style="font-size:12px;"><strong>⚠️ Stagnation Zone</strong><br>Particulate Density: Elevated</div>`).addTo(leafletMarkersGroup);

    // 2. Direct Arterial Route (Crimson dashed corridor)
    const directCoords = [
      [lat - 0.024, lng - 0.028],
      [lat - 0.012, lng - 0.012],
      [lat, lng],
      [lat + 0.014, lng + 0.016],
      [lat + 0.028, lng + 0.032]
    ];
    L.polyline(directCoords, {
      color: '#f87171',
      weight: 4,
      dashArray: '8, 6',
      opacity: 0.95
    }).bindPopup('<div style="font-size:12px;"><strong>Direct Arterial Route</strong><br>Exposure Index: <span style="color:#f87171;">82 (High Exposure)</span></div>').addTo(leafletMarkersGroup);

    // 3. Lower-Exposure Eco-Bypass Corridor (Emerald green)
    const ecoCoords = [
      [lat - 0.024, lng - 0.028],
      [lat - 0.008, lng - 0.042],
      [lat + 0.022, lng - 0.02],
      [lat + 0.028, lng + 0.032]
    ];
    L.polyline(ecoCoords, {
      color: '#22c55e',
      weight: 4.5,
      opacity: 0.95
    }).bindPopup('<div style="font-size:12px;"><strong>Eco-Bypass Corridor</strong><br><span style="color:#22c55e;font-weight:bold;">-37.8% Lower Toxic Exposure</span></div>').addTo(leafletMarkersGroup);

    // 4. City Center Pin Marker
    const pinIcon = L.divIcon({
      className: 'custom-map-pin',
      html: '<div style="width:10px;height:10px;border-radius:50%;background:#ffffff;"></div>',
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });

    L.marker([lat, lng], { icon: pinIcon })
      .bindPopup(`<div style="font-size:13px;line-height:1.4;"><strong>📍 ${state.location.name}</strong><br>AQI: <strong style="color:#f59e0b;">${aqi}</strong> (${state.aqiData.category})<br>PM2.5: ${state.aqiData.pm25} µg/m³<br>PM10: ${state.aqiData.pm10} µg/m³</div>`)
      .addTo(leafletMarkersGroup)
      .openPopup();
  }

  function renderMap() {
    if (state.mapMode === 'LEAFLET' && leafletMap) {
      leafletMap.setView([state.location.lat, state.location.lng], 12);
      updateLeafletOverlays();
      setTimeout(() => leafletMap.invalidateSize(), 50);
    } else if (state.mapMode === 'GOOGLE' && state.mapInstance) {
      state.mapInstance.setCenter({ lat: state.location.lat, lng: state.location.lng });
    } else {
      renderDemoRadarMap();
    }
  }

  function toggle3dMap() {
    state.is3d = !state.is3d;
    els.toggle3dBtn.textContent = state.is3d ? '2D Reset' : '3D Tilt';
    els.toggle3dBtn.classList.toggle('active', state.is3d);
    els.mapPanel.classList.toggle('tilt-3d', state.is3d);
    if (leafletMap) {
      setTimeout(() => leafletMap.invalidateSize(), 350);
    }
  }

  function centerMapOnCurrent() {
    if (state.mapMode === 'LEAFLET' && leafletMap) {
      leafletMap.flyTo([state.location.lat, state.location.lng], 13, { duration: 1.2 });
    } else if (state.mapMode === 'GOOGLE' && state.mapInstance) {
      state.mapInstance.setCenter({ lat: state.location.lat, lng: state.location.lng });
      state.mapInstance.setZoom(13);
    } else {
      renderDemoRadarMap();
    }
  }

  function loadGoogleMaps() {
    state.mapMode = 'GOOGLE';
    els.mapModeBadge.textContent = 'GOOGLE MAPS LIVE';
    els.mapModeBadge.className = 'status-badge live-badge';

    try {
      state.mapInstance = new google.maps.Map(els.mapPanel, {
        center: { lat: state.location.lat, lng: state.location.lng },
        zoom: 13,
        mapId: 'VAYUDRISHTI_MAP_ID',
        mapTypeId: 'hybrid',
        tilt: state.is3d ? 45 : 0,
        heading: state.is3d ? 35 : 0,
        disableDefaultUI: false
      });

      new google.maps.Marker({
        position: { lat: state.location.lat, lng: state.location.lng },
        map: state.mapInstance,
        title: state.location.name
      });
    } catch (e) {
      loadLeafletMap();
    }
  }

  // Linear High-Tech Radar Surface
  function renderDemoRadarMap() {
    state.mapMode = 'DEMO';
    els.mapModeBadge.textContent = 'DEMO RADAR';

    if (radarAnimId) cancelAnimationFrame(radarAnimId);

    els.mapPanel.innerHTML = '<canvas id="mapRadarCanvas" style="width:100%;height:100%;display:block;"></canvas>';
    const canvas = document.getElementById('mapRadarCanvas');
    if (!canvas) return;

    const rect = els.mapPanel.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = (rect.width || 600) * dpr;
    canvas.height = (rect.height || 420) * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const width = rect.width || 600;
    const height = rect.height || 420;
    const centerX = width / 2;
    const centerY = height / 2;

    let sweepAngle = 0;

    function drawLinearRadar() {
      // 1. Canvas Background: Deepest dark #030406
      ctx.fillStyle = '#030406';
      ctx.fillRect(0, 0, width, height);

      // 2. Hairline Grid (Orthogonal)
      ctx.strokeStyle = 'rgba(35, 37, 42, 0.4)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // 3. Concentric Range Rings with Distance Labels
      const rings = [
        { r: 50, label: '1.5 km' },
        { r: 100, label: '3.0 km' },
        { r: 150, label: '4.5 km' },
        { r: 200, label: '6.0 km' },
        { r: 260, label: '8.0 km' }
      ];

      rings.forEach((ring, idx) => {
        ctx.beginPath();
        ctx.arc(centerX, centerY, ring.r, 0, Math.PI * 2);
        ctx.strokeStyle = idx % 2 === 0 ? 'rgba(94, 106, 210, 0.22)' : 'rgba(255, 255, 255, 0.06)';
        ctx.lineWidth = 1;
        ctx.setLineDash(idx % 2 === 1 ? [3, 4] : []);
        ctx.stroke();
        ctx.setLineDash([]);

        // Distance Tag in JetBrains Mono
        ctx.font = '10px "JetBrains Mono", monospace';
        ctx.fillStyle = 'rgba(138, 143, 152, 0.6)';
        ctx.fillText(ring.label, centerX + 6, centerY - ring.r + 12);
      });

      // 4. Crosshair Lines with Tick Marks
      ctx.strokeStyle = 'rgba(94, 106, 210, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(centerX, 15);
      ctx.lineTo(centerX, height - 15);
      ctx.moveTo(15, centerY);
      ctx.lineTo(width - 15, centerY);
      ctx.stroke();

      // Cardinal Indicators
      ctx.font = '500 11px "Inter", sans-serif';
      ctx.fillStyle = '#828fff';
      ctx.fillText('N', centerX - 4, 18);
      ctx.fillText('S', centerX - 4, height - 6);
      ctx.fillText('W', 6, centerY + 4);
      ctx.fillText('E', width - 16, centerY + 4);

      // 5. Atmospheric Dispersion Heatmap Glow
      const heatGrad = ctx.createRadialGradient(centerX, centerY, 10, centerX, centerY, 140);
      heatGrad.addColorStop(0, 'rgba(239, 68, 68, 0.28)');
      heatGrad.addColorStop(0.4, 'rgba(245, 158, 11, 0.12)');
      heatGrad.addColorStop(0.8, 'rgba(94, 106, 210, 0.05)');
      heatGrad.addColorStop(1, 'rgba(94, 106, 210, 0)');
      ctx.fillStyle = heatGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 140, 0, Math.PI * 2);
      ctx.fill();

      // 6. Direct Arterial Route Line (Crimson, Dashed)
      ctx.strokeStyle = '#f87171';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(centerX - 160, centerY - 80);
      ctx.lineTo(centerX - 80, centerY - 25);
      ctx.lineTo(centerX, centerY);
      ctx.lineTo(centerX + 75, centerY + 45);
      ctx.lineTo(centerX + 150, centerY + 95);
      ctx.stroke();
      ctx.setLineDash([]);

      // 7. Eco-Bypass Corridor (Emerald, Smooth Bézier Arc)
      ctx.strokeStyle = '#27a644';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(centerX - 160, centerY - 80);
      ctx.bezierCurveTo(centerX - 120, centerY - 140, centerX + 110, centerY - 90, centerX + 150, centerY + 95);
      ctx.stroke();

      // 8. Dynamic Nodes with Halo Rings
      drawLinearNode(ctx, centerX, centerY, '#5e6ad2', state.location.name, true);
      drawLinearNode(ctx, centerX - 160, centerY - 80, '#27a644', 'Origin (Vijay Nagar)');
      drawLinearNode(ctx, centerX + 150, centerY + 95, '#fbbf24', 'Dest (Rajwada)');
      drawLinearNode(ctx, centerX - 80, centerY - 25, '#ef4444', 'Hotspot 1 (AB Rd)');
      drawLinearNode(ctx, centerX + 75, centerY + 45, '#ef4444', 'Hotspot 2 (Palasia)');

      // 9. Pulsating Center Radar Ping
      const now = Date.now() / 1000;
      const pulseR = (now % 2) * 35;
      const pulseAlpha = Math.max(0, 1 - (pulseR / 35));
      ctx.beginPath();
      ctx.arc(centerX, centerY, pulseR, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(94, 106, 210, ${pulseAlpha * 0.8})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // 10. Radar Sweep Beam (Linear Lavender Gradient)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(sweepAngle);
      const sweepGrad = ctx.createLinearGradient(0, 0, 180, 0);
      sweepGrad.addColorStop(0, 'rgba(94, 106, 210, 0.45)');
      sweepGrad.addColorStop(1, 'rgba(94, 106, 210, 0)');
      ctx.fillStyle = sweepGrad;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, 190, 0, Math.PI / 4);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      sweepAngle += 0.015;
      radarAnimId = requestAnimationFrame(drawLinearRadar);
    }

    function drawLinearNode(c, x, y, color, label, isCore = false) {
      // Glow Ring
      c.beginPath();
      c.arc(x, y, isCore ? 8 : 6, 0, Math.PI * 2);
      c.fillStyle = color;
      c.fill();
      c.strokeStyle = '#ffffff';
      c.lineWidth = 1.5;
      c.stroke();

      // Background Pill for Text
      c.font = '500 11px "Inter", sans-serif';
      const textWidth = c.measureText(label).width;
      c.fillStyle = 'rgba(15, 16, 17, 0.85)';
      c.fillRect(x + 10, y - 10, textWidth + 10, 18);
      c.strokeStyle = 'rgba(35, 37, 42, 0.8)';
      c.lineWidth = 1;
      c.strokeRect(x + 10, y - 10, textWidth + 10, 18);

      c.fillStyle = '#f7f8f8';
      c.fillText(label, x + 15, y + 3);
    }

    drawLinearRadar();
  }

  // =========================================================================
  // HIGH-PRECISION LINEAR CHARTS (CANVAS)
  // =========================================================================
  function renderAllGraphs() {
    renderAqi24hGraph();
    renderPmRatioGraph();
    renderForecastGraph();
    renderSourcesDonutGraph();
  }

  function renderAqi24hGraph() {
    const canvas = els.canvasAqi24h;
    if (!canvas) return;
    const parentWidth = canvas.parentElement.clientWidth || 550;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = parentWidth * dpr;
    canvas.height = 220 * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const width = parentWidth;
    const height = 220;
    const baseAqi = state.aqiData.aqi || 184;

    ctx.clearRect(0, 0, width, height);
    drawLinearGrid(ctx, width, height);

    const hours = ['00h', '04h', '08h', '12h', '16h', '20h', '24h'];
    const multipliers = [0.82, 0.75, 1.18, 0.92, 1.05, 1.22, 0.98];
    const data = multipliers.map(m => Math.round(baseAqi * m));

    drawCubicSpline(ctx, data, hours, width, height, '#5e6ad2', 'rgba(94, 106, 210, 0.22)', 350, 40);
  }

  function renderPmRatioGraph() {
    const canvas = els.canvasPmRatio;
    if (!canvas) return;
    const parentWidth = canvas.parentElement.clientWidth || 550;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = parentWidth * dpr;
    canvas.height = 220 * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const width = parentWidth;
    const height = 220;

    ctx.clearRect(0, 0, width, height);
    drawLinearGrid(ctx, width, height);

    const pm25 = state.aqiData.pm25 || 112;
    const pm10 = state.aqiData.pm10 || 178;

    const barWidth = 64;
    const startX = width / 2 - barWidth - 28;

    // Bar 1: PM2.5 (Fine) - Crimson linear gradient
    const pm25Height = (pm25 / 240) * (height - 65);
    const grad1 = ctx.createLinearGradient(0, height - 35 - pm25Height, 0, height - 35);
    grad1.addColorStop(0, 'rgba(239, 68, 68, 0.85)');
    grad1.addColorStop(1, 'rgba(239, 68, 68, 0.25)');
    ctx.fillStyle = grad1;
    roundRect(ctx, startX, height - 35 - pm25Height, barWidth, pm25Height, 6);
    ctx.fill();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = '#f7f8f8';
    ctx.font = '600 13px "JetBrains Mono", monospace';
    ctx.fillText(`${pm25} µg/m³`, startX + 6, height - 42 - pm25Height);
    ctx.fillStyle = '#8a8f98';
    ctx.font = '500 11px "Inter", sans-serif';
    ctx.fillText('PM2.5 (Fine)', startX + 4, height - 14);

    // Bar 2: PM10 (Coarse) - Amber linear gradient
    const pm10Height = (pm10 / 240) * (height - 65);
    const startX2 = startX + barWidth + 45;
    const grad2 = ctx.createLinearGradient(0, height - 35 - pm10Height, 0, height - 35);
    grad2.addColorStop(0, 'rgba(245, 158, 11, 0.85)');
    grad2.addColorStop(1, 'rgba(245, 158, 11, 0.25)');
    ctx.fillStyle = grad2;
    roundRect(ctx, startX2, height - 35 - pm10Height, barWidth, pm10Height, 6);
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = '#f7f8f8';
    ctx.font = '600 13px "JetBrains Mono", monospace';
    ctx.fillText(`${pm10} µg/m³`, startX2 + 6, height - 42 - pm10Height);
    ctx.fillStyle = '#8a8f98';
    ctx.font = '500 11px "Inter", sans-serif';
    ctx.fillText('PM10 (Coarse)', startX2 + 4, height - 14);
  }

  function renderForecastGraph() {
    const canvas = els.canvasForecast;
    if (!canvas) return;
    const parentWidth = canvas.parentElement.clientWidth || 550;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = parentWidth * dpr;
    canvas.height = 220 * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const width = parentWidth;
    const height = 220;
    const baseAqi = state.aqiData.aqi || 184;

    ctx.clearRect(0, 0, width, height);
    drawLinearGrid(ctx, width, height);

    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const forecast = [
      Math.round(baseAqi),
      Math.round(baseAqi * 1.08),
      Math.round(baseAqi * 1.18),
      Math.round(baseAqi * 1.12),
      Math.round(baseAqi * 0.95),
      Math.round(baseAqi * 0.88),
      Math.round(baseAqi * 0.82)
    ];

    drawCubicSpline(ctx, forecast, days, width, height, '#27a644', 'rgba(39, 166, 68, 0.18)', 350, 40);
  }

  function renderSourcesDonutGraph() {
    const canvas = els.canvasSourcesDonut;
    if (!canvas) return;
    const parentWidth = canvas.parentElement.clientWidth || 550;
    const dpr = window.devicePixelRatio || 1;
    canvas.width = parentWidth * dpr;
    canvas.height = 220 * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const width = parentWidth;
    const height = 220;

    ctx.clearRect(0, 0, width, height);

    const centerX = width / 2 - 70;
    const centerY = height / 2;
    const radius = 64;
    const innerRadius = 40;

    const segments = [
      { name: 'Vehicular Traffic', pct: 0.72, val: '72%', color: '#5e6ad2' },
      { name: 'Manufacturing / Boilers', pct: 0.18, val: '18%', color: '#f59e0b' },
      { name: 'Open Biomass Burning', pct: 0.10, val: '10%', color: '#2dd4bf' }
    ];

    let startAngle = -Math.PI / 2;
    segments.forEach(seg => {
      const sliceAngle = seg.pct * Math.PI * 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.arc(centerX, centerY, innerRadius, startAngle + sliceAngle, startAngle, true);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = '#0f1011';
      ctx.lineWidth = 2.5;
      ctx.stroke();
      startAngle += sliceAngle;
    });

    // Donut Center Text
    ctx.fillStyle = '#f7f8f8';
    ctx.font = '600 18px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('72%', centerX, centerY + 2);
    ctx.font = '500 10px "Inter", sans-serif';
    ctx.fillStyle = '#8a8f98';
    ctx.fillText('TRAFFIC', centerX, centerY + 16);
    ctx.textAlign = 'left';

    // Modern Legend
    let legendY = centerY - 32;
    segments.forEach(seg => {
      ctx.fillStyle = seg.color;
      ctx.beginPath();
      ctx.arc(centerX + radius + 30, legendY + 5, 4, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#f7f8f8';
      ctx.font = '500 12px "Inter", sans-serif';
      ctx.fillText(seg.name, centerX + radius + 44, legendY + 9);

      ctx.fillStyle = '#8a8f98';
      ctx.font = '600 11px "JetBrains Mono", monospace';
      ctx.fillText(seg.val, centerX + radius + 210, legendY + 9);

      legendY += 26;
    });
  }

  function drawLinearGrid(ctx, width, height) {
    ctx.strokeStyle = 'rgba(35, 37, 42, 0.6)';
    ctx.lineWidth = 1;
    for (let x = 30; x < width - 20; x += 55) {
      ctx.beginPath();
      ctx.moveTo(x, 15);
      ctx.lineTo(x, height - 35);
      ctx.stroke();
    }
    for (let y = 25; y < height - 30; y += 35) {
      ctx.beginPath();
      ctx.moveTo(25, y);
      ctx.lineTo(width - 25, y);
      ctx.stroke();
    }
  }

  // Smooth Cubic Bézier Spline Area
  function drawCubicSpline(ctx, points, labels, width, height, strokeColor, fillColor, maxVal, minVal) {
    const stepX = (width - 60) / (points.length - 1);
    const offsetX = 30;

    const pts = points.map((val, i) => {
      const px = offsetX + i * stepX;
      const py = height - 35 - ((val - minVal) / (maxVal - minVal)) * (height - 65);
      return { x: px, y: py, val };
    });

    // Gradient Area Fill
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);

    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      const cpx = (p0.x + p1.x) / 2;
      ctx.bezierCurveTo(cpx, p0.y, cpx, p1.y, p1.x, p1.y);
    }
    ctx.lineTo(pts[pts.length - 1].x, height - 35);
    ctx.lineTo(pts[0].x, height - 35);
    ctx.closePath();

    ctx.fillStyle = fillColor;
    ctx.fill();

    // Spline Line
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i];
      const p1 = pts[i + 1];
      const cpx = (p0.x + p1.x) / 2;
      ctx.bezierCurveTo(cpx, p0.y, cpx, p1.y, p1.x, p1.y);
    }
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Data Points & Text Labels
    pts.forEach((pt, i) => {
      // Glow Ring
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = strokeColor;
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Value label on hover / top
      ctx.fillStyle = '#8a8f98';
      ctx.font = '500 11px "Inter", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(labels[i], pt.x, height - 14);

      ctx.fillStyle = '#d0d6e0';
      ctx.font = '500 10px "JetBrains Mono", monospace';
      ctx.fillText(pt.val, pt.x, pt.y - 8);
    });
    ctx.textAlign = 'left';
  }

  function roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height);
    ctx.lineTo(x, y + height);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  // =========================================================================
  // WIND DYNAMICS, PREDICTIVE SPLINE & ANOMALY RADAR SUITE
  // =========================================================================

  function degToCardinal(deg) {
    const val = (Number(deg) % 360 + 360) % 360;
    const cardinals = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
    const idx = Math.round(val / 22.5) % 16;
    return cardinals[idx];
  }

  function degToCardinalFull(deg) {
    const val = (Number(deg) % 360 + 360) % 360;
    if (val >= 337.5 || val < 22.5) return 'North (0°)';
    if (val < 67.5) return 'North-East (45°)';
    if (val < 112.5) return 'East (90°)';
    if (val < 157.5) return 'South-East (135°)';
    if (val < 202.5) return 'South (180°)';
    if (val < 247.5) return 'South-West (225°)';
    if (val < 292.5) return 'West (270°)';
    return 'North-West (315°)';
  }

  function getVentilationMeta(speed) {
    const spd = Number(speed) || 0;
    if (spd < 5.0) {
      return {
        level: 'CRITICAL_STAGNATION',
        label: 'Stagnation Trap',
        color: '#eb5757',
        badgeClass: 'status-pill-danger',
        desc: 'Sub-5 km/h surface inversion traps PM2.5/PM10 within breathing zone.',
        icon: '⚠️',
        title: 'Severe Dispersion Failure (Stagnation Hazard)',
        impact: `Near-zero velocity (${spd.toFixed(1)} km/h) arrests horizontal mixing. Particulates accumulate rapidly, exacerbating hazardous AQI levels.`
      };
    }
    if (spd < 9.0) {
      return {
        level: 'LOW_DISPERSION',
        label: 'Low Mixing',
        color: '#f59e0b',
        badgeClass: 'status-pill-warning',
        desc: 'Restricted atmospheric clearing; localized hotspots in street canyons.',
        icon: '🌫️',
        title: 'Marginal Atmospheric Flushing',
        impact: `Moderate wind speed (${spd.toFixed(1)} km/h) provides limited dilution. Surface boundary layer remains prone to localized toxic trapping.`
      };
    }
    if (spd < 15.0) {
      return {
        level: 'OPTIMAL_DISPERSION',
        label: 'Optimal Dispersion',
        color: '#27a644',
        badgeClass: 'status-pill-success',
        desc: 'Steady horizontal ventilation coefficient ensures steady particulate dilution.',
        icon: '🍃',
        title: 'Optimal Atmospheric Dispersion',
        impact: `Healthy ventilation (${spd.toFixed(1)} km/h). Effective mechanical mixing flushes ambient air corridor and lowers ground-level particulate loading.`
      };
    }
    return {
      level: 'HIGH_TURBULENCE',
      label: 'High Turbulence',
      color: '#38bdf8',
      badgeClass: 'status-lavender',
      desc: 'Strong advective transport; high mechanical shear resuspends dust.',
      icon: '💨',
      title: 'Strong Advective Transport Corridor',
      impact: `Elevated velocities (${spd.toFixed(1)} km/h) accelerate boundary layer flushing, though dry surface dust resuspension may elevate coarse PM10.`
    };
  }

  function updateWindKpiCards(currentSpeed, currentDeg, histRecords, anomalies) {
    if (!els.windStatSpeed) return;

    const spd = Number(currentSpeed) || 0;
    const deg = Number(currentDeg) || 0;
    const vMeta = getVentilationMeta(spd);

    // Speed Card
    els.windStatSpeed.textContent = spd.toFixed(1);
    if (els.windStatSpeedTag) {
      els.windStatSpeedTag.textContent = spd < 5.0 ? 'CALM STAGNATION' : spd < 10.0 ? 'LIGHT BREEZE' : spd < 16.0 ? 'MODERATE BREEZE' : 'STRONG BREEZE';
      els.windStatSpeedTag.className = `status-pill ${spd < 5.0 ? 'status-pill-danger' : spd < 10.0 ? 'status-pill-warning' : 'status-pill-success'}`;
    }

    if (histRecords && histRecords.length > 0 && els.windStatMeanSpeed) {
      const avg = histRecords.reduce((a, b) => a + Number(b.avg_wind_speed_kmph || 0), 0) / histRecords.length;
      els.windStatMeanSpeed.textContent = avg.toFixed(1);
    }

    // Prevailing Vector Card
    if (els.windStatAngle) els.windStatAngle.textContent = Math.round(deg);
    if (els.windStatCardinal) els.windStatCardinal.textContent = degToCardinal(deg);
    if (els.windStatAngleFull) els.windStatAngleFull.textContent = degToCardinalFull(deg);

    // Ventilation Card
    if (els.windStatVentilation) {
      els.windStatVentilation.textContent = vMeta.label;
      els.windStatVentilation.style.color = vMeta.color;
    }
    if (els.windStatVentilationPill) {
      els.windStatVentilationPill.textContent = vMeta.level.replace('_', ' ');
      els.windStatVentilationPill.className = `status-pill ${vMeta.badgeClass}`;
    }
    if (els.windStatVentilationDesc) {
      els.windStatVentilationDesc.textContent = vMeta.desc;
    }

    // Anomaly Card
    if (els.windStatAnomalyCount) {
      els.windStatAnomalyCount.textContent = anomalies.length;
    }
    if (els.windStatAnomalyPill) {
      const stagCount = anomalies.filter(a => (a.anomaly_type || '').includes('STAGNATION')).length;
      if (stagCount > 0) {
        els.windStatAnomalyPill.textContent = `${stagCount} STAGNATION TRAPS`;
        els.windStatAnomalyPill.className = 'status-pill status-pill-danger';
      } else if (anomalies.length > 0) {
        els.windStatAnomalyPill.textContent = `${anomalies.length} IRREGULARITIES`;
        els.windStatAnomalyPill.className = 'status-pill status-pill-warning';
      } else {
        els.windStatAnomalyPill.textContent = 'NO ACTIVE ALERTS';
        els.windStatAnomalyPill.className = 'status-pill status-pill-success';
      }
    }
  }

  function renderWindCompass(speed, deg, u, v) {
    if (!els.windCompassNeedle) return;

    const angle = Number(deg) || 0;
    const spd = Number(speed) || 0;
    const cardinal = degToCardinal(angle);
    const meta = getVentilationMeta(spd);

    // Rotate the needle arrow smoothly
    els.windCompassNeedle.style.transform = `rotate(${Math.round(angle)}deg)`;

    // HUD labels
    if (els.hudCompassDeg) els.hudCompassDeg.textContent = `${Math.round(angle)}°`;
    if (els.hudCompassCard) els.hudCompassCard.textContent = cardinal;
    if (els.hudCompassSpeed) els.hudCompassSpeed.textContent = `${spd.toFixed(1)} km/h`;

    // Cartesian decomposition
    const uVal = Number(u) || 0;
    const vVal = Number(v) || 0;
    if (els.windVectorU) {
      els.windVectorU.textContent = `${uVal >= 0 ? '+' : ''}${uVal.toFixed(2)} m/s`;
      els.windVectorU.style.color = uVal < 0 ? '#ff8080' : '#828fff';
    }
    if (els.windVectorV) {
      els.windVectorV.textContent = `${vVal >= 0 ? '+' : ''}${vVal.toFixed(2)} m/s`;
      els.windVectorV.style.color = vVal < 0 ? '#ff8080' : '#828fff';
    }

    // Advisory callout banner
    if (els.windAdvisoryIcon) els.windAdvisoryIcon.textContent = meta.icon;
    if (els.windAdvisoryTitle) {
      els.windAdvisoryTitle.textContent = meta.title;
      els.windAdvisoryTitle.style.color = meta.color;
    }
    if (els.windAdvisoryBody) {
      els.windAdvisoryBody.textContent = meta.impact;
    }
    if (els.windAdvisoryBanner) {
      els.windAdvisoryBanner.style.borderColor = `${meta.color}44`;
      els.windAdvisoryBanner.style.background = `${meta.color}11`;
    }
  }

  function renderWindForecastSteps(forecast) {
    if (!els.windForecastStepsRow) return;
    if (!forecast || forecast.length === 0) {
      els.windForecastStepsRow.innerHTML = '<div class="text-subtle" style="font-size:11px; padding:6px;">No forecast projection loaded.</div>';
      return;
    }

    els.windForecastStepsRow.innerHTML = forecast.map((step, idx) => {
      const spd = Number(step.predicted_speed_kmph || step.speed_kmph || 0).toFixed(1);
      const deg = Math.round(step.predicted_direction_deg || step.direction_deg || 0);
      const card = step.cardinal || step.direction_label || degToCardinal(deg);
      const mName = (step.month || `M${step.step || idx + 1}`).substring(0, 3).toUpperCase();
      const isStagnant = Number(spd) < 5.0;

      return `
        <div class="forecast-step-chip hand-tab" data-step-idx="${idx}" title="Click to preview polar vector for ${step.month} 2025" style="${isStagnant ? 'border-color:#eb5757; background:rgba(235,87,87,0.08);' : ''}">
          <span class="step-month-name">${mName} 2025</span>
          <span class="step-speed-val" style="color:${isStagnant ? '#eb5757' : '#00d2ff'};">${spd} <small style="font-size:9px; font-weight:normal;">km/h</small></span>
          <div class="step-direction-row">
            <span>${card} (${deg}°)</span>
            <span style="font-size:11px; transform:rotate(${deg}deg); display:inline-block;">&uarr;</span>
          </div>
        </div>
      `;
    }).join('');

    // Attach click listener to preview individual steps on the compass HUD
    els.windForecastStepsRow.querySelectorAll('.forecast-step-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const idx = parseInt(chip.getAttribute('data-step-idx'), 10);
        const step = forecast[idx];
        if (step) {
          const spd = Number(step.predicted_speed_kmph || 0);
          const deg = Number(step.predicted_direction_deg || 0);
          const u = step.u_vector ?? step.predicted_u_ms ?? (-spd * Math.sin(deg * Math.PI / 180) / 3.6);
          const v = step.v_vector ?? step.predicted_v_ms ?? (-spd * Math.cos(deg * Math.PI / 180) / 3.6);
          renderWindCompass(spd, deg, Number(u).toFixed(2), Number(v).toFixed(2));
          showAuthToast(`Previewing projected vector for ${step.month} 2025: ${spd.toFixed(1)} km/h at ${deg}° (${step.cardinal || degToCardinal(deg)})`);
        }
      });
    });
  }

  function handleForecastCanvasHover(e) {
    if (!els.canvasWindForecast) return;
    const canvas = els.canvasWindForecast;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const hist = state.windData.history || [];
    const fc = state.windData.forecast || [];
    const totalPoints = hist.length + fc.length;
    if (totalPoints === 0) return;

    const padLeft = 45;
    const padRight = 30;
    const chartW = rect.width - padLeft - padRight;
    const stepX = chartW / Math.max(1, totalPoints - 1);

    const rawIdx = Math.round((mouseX - padLeft) / stepX);
    const clampedIdx = Math.max(0, Math.min(totalPoints - 1, rawIdx));

    state.windData.hoverPoint = {
      index: clampedIdx,
      mouseX: mouseX,
      mouseY: mouseY
    };

    renderWindForecastChart();
  }

  function renderWindForecastChart() {
    const canvas = els.canvasWindForecast;
    if (!canvas) return;

    const parent = canvas.parentElement;
    const width = parent ? parent.clientWidth : 700;
    const height = 280;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);

    const hist = state.windData.history || [];
    const fc = state.windData.forecast || [];
    const totalPoints = hist.length + fc.length;

    if (totalPoints === 0) {
      ctx.fillStyle = '#6b7280';
      ctx.font = '12px "Inter", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('No wind telemetry dataset available for spline rendering.', width / 2, height / 2);
      return;
    }

    const padLeft = 45;
    const padRight = 30;
    const padTop = 30;
    const padBottom = 35;
    const chartW = width - padLeft - padRight;
    const chartH = height - padTop - padBottom;

    // Collect all speeds to determine Y scale
    const allSpeeds = [
      ...hist.map(r => Number(r.speed_kmph ?? r.avg_wind_speed_kmph ?? 0)),
      ...fc.map(r => Number(r.predicted_speed_kmph || 0)),
      ...fc.map(r => Number(r.ci_upper_85 || 0))
    ];
    const maxVal = Math.max(22, Math.ceil(Math.max(...allSpeeds) / 5) * 5);
    const minVal = 0;

    function getX(i) {
      return padLeft + (i / Math.max(1, totalPoints - 1)) * chartW;
    }

    function getY(val) {
      const norm = (val - minVal) / (maxVal - minVal);
      return padTop + chartH - norm * chartH;
    }

    // 1. Draw Stagnation Trap Hazard Zone (< 5 km/h)
    const stagY = getY(5.0);
    const bottomY = getY(0.0);
    const stagGrad = ctx.createLinearGradient(0, stagY, 0, bottomY);
    stagGrad.addColorStop(0, 'rgba(235, 87, 87, 0.12)');
    stagGrad.addColorStop(1, 'rgba(235, 87, 87, 0.02)');
    ctx.fillStyle = stagGrad;
    ctx.fillRect(padLeft, stagY, chartW, bottomY - stagY);

    // Stagnation Danger Line (5 km/h dashed red)
    ctx.beginPath();
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = 'rgba(235, 87, 87, 0.7)';
    ctx.lineWidth = 1.2;
    ctx.moveTo(padLeft, stagY);
    ctx.lineTo(padLeft + chartW, stagY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#eb5757';
    ctx.font = '600 10px "JetBrains Mono", monospace';
    ctx.textAlign = 'right';
    ctx.fillText('CRITICAL STAGNATION THRESHOLD (5.0 km/h)', padLeft + chartW - 6, stagY - 5);

    // 2. Grid Lines & Y-Axis Labels
    const ySteps = 5;
    ctx.fillStyle = '#626670';
    ctx.font = '500 10px "JetBrains Mono", monospace';
    ctx.textAlign = 'right';

    for (let s = 0; s <= ySteps; s++) {
      const v = minVal + (s / ySteps) * (maxVal - minVal);
      const y = getY(v);

      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      ctx.moveTo(padLeft, y);
      ctx.lineTo(padLeft + chartW, y);
      ctx.stroke();

      ctx.fillText(`${v.toFixed(0)}`, padLeft - 8, y + 3);
    }

    // 3. Draw 85% Confidence Interval Band for 2025 Forecast
    if (fc.length > 0) {
      const fcStartIndex = hist.length;
      ctx.beginPath();
      // Upper bound forward
      for (let i = 0; i < fc.length; i++) {
        const ptIdx = fcStartIndex + i;
        const x = getX(ptIdx);
        const yUpper = getY(Number(fc[i].ci_upper_85 || fc[i].predicted_speed_kmph + 1.8));
        if (i === 0) ctx.moveTo(x, yUpper);
        else ctx.lineTo(x, yUpper);
      }
      // Lower bound backward
      for (let i = fc.length - 1; i >= 0; i--) {
        const ptIdx = fcStartIndex + i;
        const x = getX(ptIdx);
        const yLower = getY(Number(fc[i].ci_lower_85 || Math.max(1, fc[i].predicted_speed_kmph - 1.8)));
        ctx.lineTo(x, yLower);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(0, 210, 255, 0.12)';
      ctx.fill();

      // Top CI dashed edge
      ctx.beginPath();
      ctx.setLineDash([2, 3]);
      ctx.strokeStyle = 'rgba(0, 210, 255, 0.4)';
      ctx.lineWidth = 1;
      for (let i = 0; i < fc.length; i++) {
        const ptIdx = fcStartIndex + i;
        const x = getX(ptIdx);
        const yUpper = getY(Number(fc[i].ci_upper_85 || fc[i].predicted_speed_kmph + 1.8));
        if (i === 0) ctx.moveTo(x, yUpper);
        else ctx.lineTo(x, yUpper);
      }
      ctx.stroke();

      // Bottom CI dashed edge
      ctx.beginPath();
      for (let i = 0; i < fc.length; i++) {
        const ptIdx = fcStartIndex + i;
        const x = getX(ptIdx);
        const yLower = getY(Number(fc[i].ci_lower_85 || Math.max(1, fc[i].predicted_speed_kmph - 1.8)));
        if (i === 0) ctx.moveTo(x, yLower);
        else ctx.lineTo(x, yLower);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // 4. Draw Historical Spline (2020–2024)
    if (hist.length > 0) {
      const histCoords = hist.map((r, i) => ({
        x: getX(i),
        y: getY(Number(r.speed_kmph ?? r.avg_wind_speed_kmph ?? 0))
      }));

      ctx.beginPath();
      ctx.moveTo(histCoords[0].x, histCoords[0].y);
      for (let i = 0; i < histCoords.length - 1; i++) {
        const p0 = histCoords[i];
        const p1 = histCoords[i + 1];
        const mx = (p0.x + p1.x) / 2;
        ctx.bezierCurveTo(mx, p0.y, mx, p1.y, p1.x, p1.y);
      }
      ctx.strokeStyle = '#5e6ad2';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Subtle year divider marks
      const monthsPerYear = 12;
      ctx.fillStyle = '#8a8f98';
      ctx.font = '500 10px "Inter", sans-serif';
      ctx.textAlign = 'center';

      for (let yIdx = 0; yIdx < 5; yIdx++) {
        const mIdx = yIdx * monthsPerYear + 6;
        if (mIdx < hist.length) {
          const yr = 2020 + yIdx;
          ctx.fillText(`${yr}`, getX(mIdx), height - 12);
        }
      }
    }

    // 5. Draw 2025 Forecast Spline
    if (fc.length > 0) {
      const fcStartIndex = hist.length;
      const fcCoords = [];

      // Bridge from last historical point
      if (hist.length > 0) {
        fcCoords.push({
          x: getX(hist.length - 1),
          y: getY(Number(hist[hist.length - 1].speed_kmph ?? hist[hist.length - 1].avg_wind_speed_kmph ?? 0))
        });
      }

      fc.forEach((step, i) => {
        fcCoords.push({
          x: getX(fcStartIndex + i),
          y: getY(Number(step.predicted_speed_kmph || 0))
        });
      });

      // Forecast line
      ctx.beginPath();
      ctx.moveTo(fcCoords[0].x, fcCoords[0].y);
      for (let i = 0; i < fcCoords.length - 1; i++) {
        const p0 = fcCoords[i];
        const p1 = fcCoords[i + 1];
        const mx = (p0.x + p1.x) / 2;
        ctx.bezierCurveTo(mx, p0.y, mx, p1.y, p1.x, p1.y);
      }
      ctx.strokeStyle = '#00d2ff';
      ctx.lineWidth = 2.5;
      ctx.shadowColor = 'rgba(0, 210, 255, 0.4)';
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Draw glowing nodes on forecast points
      fc.forEach((step, i) => {
        const x = getX(fcStartIndex + i);
        const y = getY(Number(step.predicted_speed_kmph || 0));
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#00d2ff';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });

      // Forecast section label on X-axis
      const fcMidX = getX(fcStartIndex + Math.floor(fc.length / 2));
      ctx.fillStyle = '#00d2ff';
      ctx.font = '600 11px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText('2025 (ML FORECAST)', fcMidX, height - 12);
    }

    // 6. Vertical transition line separating history and forecast
    if (hist.length > 0 && fc.length > 0) {
      const transX = getX(hist.length - 0.5);
      ctx.beginPath();
      ctx.setLineDash([3, 3]);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
      ctx.lineWidth = 1;
      ctx.moveTo(transX, padTop);
      ctx.lineTo(transX, padTop + chartH);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // 7. Render Hover Tooltip
    if (state.windData.hoverPoint) {
      const hIdx = state.windData.hoverPoint.index;
      const isHistorical = hIdx < hist.length;
      const dataPoint = isHistorical ? hist[hIdx] : fc[hIdx - hist.length];

      if (dataPoint) {
        const ptX = getX(hIdx);
        const speed = isHistorical ? Number(dataPoint.speed_kmph ?? dataPoint.avg_wind_speed_kmph) : Number(dataPoint.predicted_speed_kmph);
        const deg = isHistorical ? Number(dataPoint.direction_deg ?? dataPoint.dominant_wind_direction_deg) : Number(dataPoint.predicted_direction_deg);
        const ptY = getY(speed);
        const monthYear = `${dataPoint.month || ''} ${dataPoint.year || ''}`;

        // Crosshair vertical line
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 1;
        ctx.moveTo(ptX, padTop);
        ctx.lineTo(ptX, padTop + chartH);
        ctx.stroke();

        // Highlight ring
        ctx.beginPath();
        ctx.arc(ptX, ptY, 6, 0, Math.PI * 2);
        ctx.fillStyle = isHistorical ? '#5e6ad2' : '#00d2ff';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Tooltip box
        const tipW = 160;
        const tipH = 75;
        let tipX = ptX + 12;
        if (tipX + tipW > width - padRight) tipX = ptX - tipW - 12;
        let tipY = Math.max(padTop + 5, Math.min(height - padBottom - tipH - 5, ptY - 35));

        ctx.fillStyle = 'rgba(10, 11, 14, 0.95)';
        ctx.strokeStyle = isHistorical ? 'rgba(94, 106, 210, 0.5)' : 'rgba(0, 210, 255, 0.6)';
        ctx.lineWidth = 1;
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 12;
        roundRect(ctx, tipX, tipY, tipW, tipH, 6);
        ctx.fill();
        ctx.stroke();
        ctx.shadowBlur = 0;

        ctx.textAlign = 'left';
        ctx.font = '600 11px "Inter", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.fillText(monthYear, tipX + 10, tipY + 18);

        ctx.font = '500 10px "JetBrains Mono", monospace';
        ctx.fillStyle = isHistorical ? '#828fff' : '#00d2ff';
        ctx.fillText(`Velocity: ${speed.toFixed(1)} km/h`, tipX + 10, tipY + 34);

        ctx.fillStyle = '#9ca3af';
        ctx.fillText(`Vector: ${Math.round(deg)}° (${degToCardinal(deg)})`, tipX + 10, tipY + 49);

        const vStatus = getVentilationMeta(speed);
        ctx.fillStyle = vStatus.color;
        ctx.fillText(`${vStatus.label}`, tipX + 10, tipY + 64);
      }
    }
  }

  function renderAnomalyFeed() {
    if (!els.windAnomalyFeed) return;

    const anomalies = state.windData.anomalies || [];
    const filter = state.windData.activeAnomalyFilter || 'ALL';

    const stagCount = anomalies.filter(a => (a.anomaly_type || '').includes('STAGNATION')).length;
    const gustCount = anomalies.filter(a => (a.anomaly_type || '').includes('GUST')).length;
    const shearCount = anomalies.filter(a => (a.anomaly_type || '').includes('SHEAR')).length;

    if (els.statStagnationCount) els.statStagnationCount.textContent = stagCount;
    if (els.statGustCount) els.statGustCount.textContent = gustCount;
    if (els.statShearCount) els.statShearCount.textContent = shearCount;

    if (els.badgeCountAll) els.badgeCountAll.textContent = anomalies.length;
    if (els.badgeCountStag) els.badgeCountStag.textContent = stagCount;
    if (els.badgeCountGust) els.badgeCountGust.textContent = gustCount;
    if (els.badgeCountShear) els.badgeCountShear.textContent = shearCount;

    const filtered = anomalies.filter(item => {
      const type = item.anomaly_type || '';
      if (filter === 'STAGNATION') return type.includes('STAGNATION');
      if (filter === 'GUST') return type.includes('GUST');
      if (filter === 'SHEAR') return type.includes('SHEAR');
      return true;
    });

    if (filtered.length === 0) {
      els.windAnomalyFeed.innerHTML = `
        <div class="anomaly-empty-state">
          <span>🛡️</span>
          <p>No atmospheric irregularities detected for category "${filter}". Wind dispersion is normal.</p>
        </div>`;
      return;
    }

    els.windAnomalyFeed.innerHTML = filtered.map(item => {
      const isStag = (item.anomaly_type || '').includes('STAGNATION');
      const isGust = (item.anomaly_type || '').includes('GUST');
      const borderClass = isStag ? 'border-critical' : isGust ? 'border-warning' : 'border-info';
      const severityClass = item.severity === 'CRITICAL' ? 'status-pill-danger' : item.severity === 'HIGH' ? 'status-pill-danger' : 'status-pill-warning';

      const spd = Number(item.speed_kmph || 0).toFixed(1);
      const deg = Math.round(item.direction_deg || 0);
      const card = item.cardinal || degToCardinal(deg);
      const zScore = item.z_score != null ? (item.z_score > 0 ? `+${item.z_score}` : item.z_score) : null;
      const impact = item.impact_advisory || item.impact_analysis || (isStag ? 'Severe surface inversion traps PM2.5 within breathing layer.' : 'Atypical atmospheric circulation corridor.');

      return `
        <div class="anomaly-item-card ${borderClass}">
          <div class="anomaly-card-top">
            <div class="anomaly-date-badge">${item.month} ${item.year}</div>
            <div class="anomaly-badge-group">
              <span class="status-pill ${severityClass}">${item.severity || 'ALERT'}</span>
              <span class="status-pill status-lavender">${(item.anomaly_type || 'ANOMALY').replace(/_/g, ' ')}</span>
            </div>
          </div>
          <div class="anomaly-card-metrics">
            <span>Observed Speed: <strong class="text-ink-white">${spd} km/h</strong></span>
            <span>Vector: <strong class="text-ink-white">${deg}° (${card})</strong></span>
            ${item.expected_speed_kmph != null ? `<span>Seasonal Norm: <strong class="text-ink-white">${item.expected_speed_kmph} km/h</strong></span>` : ''}
            ${zScore ? `<span>Z-Score: <strong class="${Math.abs(item.z_score) > 2 ? 'text-danger' : 'text-warning'}">${zScore}</strong></span>` : ''}
          </div>
          <div class="anomaly-impact-text">${impact}</div>
        </div>
      `;
    }).join('');
  }

  async function loadWindAnalytics(forceCity, forceHorizon) {
    const city = forceCity || state.windData.currentCity || 'Kolkata';
    const horizon = forceHorizon || state.windData.horizonMonths || 12;

    if (els.windCitySelector && els.windCitySelector.value !== city) {
      els.windCitySelector.value = city;
    }
    if (els.windForecastHorizon && parseInt(els.windForecastHorizon.value, 10) !== horizon) {
      els.windForecastHorizon.value = horizon;
    }

    if (els.windAnomalyFeed) {
      els.windAnomalyFeed.innerHTML = `
        <div class="anomaly-empty-state">
          <span class="spinner-linear"></span>
          <p>Evaluating 60 monthly atmospheric observations through Harmonic Vector Ridge & Isolation Forest...</p>
        </div>`;
    }

    try {
      // 1. Fetch History
      const histResp = await fetch(`/api/wind/history?city=${encodeURIComponent(city)}`);
      const histData = await histResp.json();
      const histRecords = histData.data?.timeline || histData.timeline || histData.historical_records || [];
      state.windData.history = histRecords;
      state.windData.statistics = histData.data?.statistics || histData.statistics || {};

      // 2. Fetch Prediction
      const predResp = await fetch('/api/wind/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ city, horizon_months: horizon })
      });
      const predData = await predResp.json();
      const pData = predData.data || predData;
      state.windData.forecast = pData.forecast || [];
      state.windData.modelArch = pData.model_architecture || 'Harmonic Vector Ridge Regression';
      const rmse = pData.mean_residual_error != null ? pData.mean_residual_error : (pData.metrics?.speed_rmse || 0.55);
      state.windData.modelRmse = rmse;

      if (els.windModelArch) els.windModelArch.textContent = state.windData.modelArch;
      if (els.windModelRmse) els.windModelRmse.textContent = `${Number(rmse).toFixed(3)} km/h`;

      // 3. Fetch Anomalies
      const anomResp = await fetch('/api/wind/anomalies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ city, contamination: 0.08 })
      });
      const anomData = await anomResp.json();
      const aData = anomData.data || anomData;
      const anomalies = aData.flagged_anomalies || (aData.records ? aData.records.filter(r => r.is_anomaly) : (aData.anomalies || []));
      state.windData.anomalies = anomalies;
      state.windData.summary = {
        stagnation_events: aData.stagnation_hazards_count != null ? aData.stagnation_hazards_count : (aData.summary?.stagnation_events || anomalies.filter(a => (a.anomaly_type || '').includes('STAGNATION')).length),
        gust_events: aData.gust_events_count != null ? aData.gust_events_count : (aData.summary?.gust_events || anomalies.filter(a => (a.anomaly_type || '').includes('GUST')).length),
        shear_events: aData.shear_events_count != null ? aData.shear_events_count : (aData.summary?.shear_events || anomalies.filter(a => (a.anomaly_type || '').includes('SHEAR')).length)
      };

      // Determine latest observation or first prediction step
      const latestHist = histRecords.length > 0 ? histRecords[histRecords.length - 1] : null;
      const currentSpeed = latestHist ? Number(latestHist.speed_kmph ?? latestHist.avg_wind_speed_kmph) : (state.windData.forecast[0]?.predicted_speed_kmph || 12.0);
      const currentDeg = latestHist ? Number(latestHist.direction_deg ?? latestHist.dominant_wind_direction_deg) : (state.windData.forecast[0]?.predicted_direction_deg || 180);
      state.windData.latestSpeed = currentSpeed;
      state.windData.latestDirection = currentDeg;

      // Update Top KPIs
      updateWindKpiCards(currentSpeed, currentDeg, histRecords, anomalies);

      // Render Compass HUD
      const firstStep = state.windData.forecast[0];
      const u = firstStep ? (firstStep.u_vector ?? firstStep.predicted_u_ms ?? (-currentSpeed * Math.sin(currentDeg * Math.PI / 180) / 3.6)) : 0;
      const v = firstStep ? (firstStep.v_vector ?? firstStep.predicted_v_ms ?? (-currentSpeed * Math.cos(currentDeg * Math.PI / 180) / 3.6)) : 0;
      renderWindCompass(currentSpeed, currentDeg, Number(u).toFixed(2), Number(v).toFixed(2));

      // Render Forecast Spline & Steps Row
      renderWindForecastChart();
      renderWindForecastSteps(state.windData.forecast);

      // Render Anomaly Feed
      renderAnomalyFeed();

    } catch (err) {
      console.error('Wind pipeline sync error:', err);
      showAuthToast('Telemetry gateway offline, loading local cached projection', true);
    }
  }

  // =========================================================================
  // GEOSPATIAL HAZARD RADAR & POLLUTION MOVEMENT MAP
  // =========================================================================
  function initSimulatorMap() {
    if (!els.simulatorMap) return;
    if (typeof L === 'undefined') return;

    if (!simulatorLeafletMap) {
      try {
        simulatorLeafletMap = L.map(els.simulatorMap, {
          center: [state.location.lat, state.location.lng],
          zoom: 13,
          zoomControl: true,
          attributionControl: false
        });

        L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
          maxZoom: 19,
          subdomains: 'abcd',
          attribution: 'CartoDB Dark Matter'
        }).addTo(simulatorLeafletMap);

        simulatorOverlaysGroup = L.layerGroup().addTo(simulatorLeafletMap);
      } catch (err) {
        console.warn('Simulator map init error:', err);
      }
    }

    setTimeout(() => {
      if (simulatorLeafletMap) {
        simulatorLeafletMap.invalidateSize();
        updateSimulatorMapOverlays();
      }
    }, 120);
  }

  function updateSimulatorMapOverlays() {
    if (!simulatorLeafletMap || !simulatorOverlaysGroup) return;
    simulatorOverlaysGroup.clearLayers();

    const userLat = state.location.lat;
    const userLng = state.location.lng;

    // Upwind Hotspot location (~2.4 km Northwest)
    const fireLat = Number((userLat + 0.016).toFixed(4));
    const fireLng = Number((userLng - 0.018).toFixed(4));
    const conf = state.verificationData.fireConfidence || 87;

    // 1. Fire Hotspot Pulse Marker
    const fireIcon = L.divIcon({
      className: 'sim-fire-pin',
      html: `
        <div style="position:relative; width:34px; height:34px; display:flex; align-items:center; justify-content:center;">
          <div style="position:absolute; width:32px; height:32px; border-radius:50%; background:rgba(239, 68, 68, 0.4); animation:notifPulse 1.5s infinite ease-in-out;"></div>
          <div style="position:relative; width:22px; height:22px; border-radius:50%; background:#ef4444; border:2px solid #ffffff; display:flex; align-items:center; justify-content:center; font-size:12px; box-shadow:0 0 12px #ef4444;">🔥</div>
        </div>
      `,
      iconSize: [34, 34],
      iconAnchor: [17, 17]
    });

    const fireMarker = L.marker([fireLat, fireLng], { icon: fireIcon }).addTo(simulatorOverlaysGroup);
    fireMarker.bindPopup(`
      <div style="font-family:Inter,sans-serif; font-size:12px; line-height:1.4; color:#111;">
        <strong style="color:#ef4444; font-size:13px;">🔥 Active Thermal Hotspot</strong><br>
        <strong>Sensor:</strong> Sentinel-3 SLSTR / VIIRS<br>
        <strong>Distance:</strong> 2.4 km Northwest<br>
        <strong>Confidence:</strong> ${conf}%<br>
        <strong>Surface Wind:</strong> NW &rarr; SE at 12.5 km/h
      </div>
    `);

    // 2. Affected Hazard Buffer Zone (Circle around hotspot)
    L.circle([fireLat, fireLng], {
      color: '#ef4444',
      fillColor: '#ef4444',
      fillOpacity: 0.16,
      radius: 1800,
      weight: 1.5,
      dashArray: '4, 4'
    }).bindPopup('<div style="font-size:11px;color:#111;">⚠️ Primary Combustion Hazard Zone (1.8 km radius)</div>').addTo(simulatorOverlaysGroup);

    // 3. Smoke Plume Dispersion Corridor (Polygon spreading from fire along NW wind vector towards user area)
    const plumeApex = [fireLat, fireLng];
    const plumeSpreadLeft = [userLat + 0.008, userLng + 0.015];
    const plumeTail = [userLat - 0.012, userLng + 0.022];
    const plumeSpreadRight = [userLat - 0.014, userLng - 0.006];

    L.polygon([plumeApex, plumeSpreadLeft, plumeTail, plumeSpreadRight], {
      color: '#a855f7',
      fillColor: '#a855f7',
      fillOpacity: 0.24,
      weight: 1.5
    }).bindPopup(`
      <div style="font-size:12px; font-family:Inter,sans-serif; color:#111;">
        <strong style="color:#7c3aed;">🌫️ Smoke &amp; Aerosol Dispersion Plume</strong><br>
        Trajectory: Direct downwind advection towards your sector.<br>
        PM2.5 Delta: +45 µg/m³ optical surge.<br>
        Estimated Inversion Arrival: ~45 min.
      </div>
    `).addTo(simulatorOverlaysGroup);

    // 4. Pollution Movement Trajectory Vector (Polyline with arrow)
    L.polyline([[fireLat, fireLng], [userLat, userLng]], {
      color: '#fbbf24',
      weight: 3,
      dashArray: '6, 6',
      opacity: 0.85
    }).addTo(simulatorOverlaysGroup);

    // 5. User Location Pin
    const userIcon = L.divIcon({
      className: 'sim-user-pin',
      html: `
        <div style="position:relative; width:28px; height:28px; display:flex; align-items:center; justify-content:center;">
          <div style="position:absolute; width:26px; height:26px; border-radius:50%; background:rgba(56, 189, 248, 0.4); animation:notifPulse 2s infinite ease-in-out;"></div>
          <div style="position:relative; width:16px; height:16px; border-radius:50%; background:#38bdf8; border:2px solid #ffffff; box-shadow:0 0 8px #38bdf8;"></div>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    const userMarker = L.marker([userLat, userLng], { icon: userIcon }).addTo(simulatorOverlaysGroup);
    userMarker.bindPopup(`
      <div style="font-family:Inter,sans-serif; font-size:12px; line-height:1.4; color:#111;">
        <strong style="color:#0284c7;">📍 ${state.location.name}</strong><br>
        Predicted AQI: <strong>${state.aqiData.aqi || 184}</strong><br>
        Predicted PM2.5: <strong>${state.aqiData.pm25 || 112} µg/m³</strong><br>
        Status: In Downwind Exposure Corridor
      </div>
    `);

    // Fit bounds to show fire, plume, and user with padding
    try {
      const groupBounds = L.latLngBounds([[fireLat, fireLng], [userLat, userLng], plumeTail]);
      simulatorLeafletMap.fitBounds(groupBounds, { padding: [40, 40], maxZoom: 14 });
    } catch (e) {}
  }

  // =========================================================================
  // REAL-TIME PREDICTION VERIFICATION & FIRE/SMOKE LOGIC
  // =========================================================================
  async function loadPredictionVerification() {
    const horizon = state.verificationData.activeHorizon || '1h';
    const baseAqi = state.aqiData.aqi || 184;
    const basePm25 = state.aqiData.pm25 || 112;

    // Horizon adjustment
    const predAqi = horizon === '2h' ? Math.round(baseAqi * 1.18) : baseAqi;
    const predPm25 = horizon === '2h' ? Math.round(basePm25 * 1.22) : basePm25;

    if (els.verifyPredAqi) els.verifyPredAqi.textContent = predAqi;
    if (els.verifyPredPm25) els.verifyPredPm25.textContent = `${predPm25} µg/m³`;
    if (els.verifyCurrentLoc) els.verifyCurrentLoc.textContent = state.location.name;
    if (els.verifyTimestamp) els.verifyTimestamp.textContent = 'Updated 2m ago';

    // 1. Fetch Human AQI Verification Stats
    try {
      const cityParam = encodeURIComponent(state.location.name);
      const resp = await fetch(`/api/verify-aqi?city=${cityParam}`);
      const data = await resp.json();
      if (data.success && data.stats) {
        state.verificationData.stats = data.stats;
        renderAgreementUi(data.stats);
      }
    } catch (e) {
      renderAgreementUi(state.verificationData.stats);
    }

    // 2. Fetch Fire Events & Dynamic Confidence
    try {
      const cityParam = encodeURIComponent(state.location.name);
      const fResp = await fetch(`/api/fire-events?city=${cityParam}&lat=${state.location.lat}&lng=${state.location.lng}`);
      const fData = await fResp.json();
      if (fData.success) {
        state.verificationData.fireConfidence = fData.currentConfidence || 87;
        state.verificationData.fireStatusText = fData.statusText || 'Potential fire detected nearby';
        state.verificationData.fireEvents = fData.events || [];
        renderFireConfidenceUi(fData.currentConfidence, fData.statusText, fData.impactLevel);
      }
    } catch (e) {
      renderFireConfidenceUi(state.verificationData.fireConfidence, state.verificationData.fireStatusText, 'HIGH_ALERT');
    }
  }

  function renderAgreementUi(stats) {
    const pct = stats.confirmedPct != null ? stats.confirmedPct : 84;
    const total = stats.totalReports || 17;
    const confirmed = stats.confirmedCount != null ? stats.confirmedCount : 14;
    const disputed = stats.disputedCount != null ? stats.disputedCount : 3;

    if (els.agreementPctText) {
      els.agreementPctText.textContent = `${pct}% Agree`;
      els.agreementPctText.className = pct >= 75 ? 'agreement-pct text-success' : 'agreement-pct text-warning';
    }
    if (els.agreementProgressFill) {
      els.agreementProgressFill.style.width = `${pct}%`;
    }
    if (els.agreementDetailsText) {
      els.agreementDetailsText.textContent = `${pct}% of nearby users agree with this prediction (${confirmed} verified, ${disputed} reported different)`;
    }
  }

  function renderFireConfidenceUi(confidence, statusText, impactLevel) {
    const conf = confidence || 87;
    if (els.fireConfidenceScoreText) els.fireConfidenceScoreText.textContent = `${conf}%`;
    if (els.fireConfidenceFill) els.fireConfidenceFill.style.width = `${conf}%`;
    if (els.fireConfidenceStatusDesc) els.fireConfidenceStatusDesc.textContent = statusText || 'Potential fire detected nearby';
    if (els.fireStatusPill) {
      els.fireStatusPill.textContent = statusText || 'Potential fire detected nearby';
      els.fireStatusPill.className = conf >= 75 ? 'status-pill status-danger' : (conf >= 50 ? 'status-pill status-warning' : 'status-pill status-lavender');
    }

    if (els.simHazardBadge) {
      els.simHazardBadge.textContent = conf >= 50 ? `🔥 1 ACTIVE HOTSPOT (${conf}% CONF)` : `🟢 NO ACTIVE SATELLITE HOTSPOT`;
      els.simHazardBadge.className = conf >= 75 ? 'status-pill status-danger' : 'status-pill status-warning';
    }
  }

  async function submitAqiVerification(vote, reason = null, otherText = null) {
    const sessionId = sessionStorage.getItem('vayudrishti_session_id') || ('s_' + Date.now());
    sessionStorage.setItem('vayudrishti_session_id', sessionId);

    const payload = {
      sessionId,
      city: state.location.name,
      area: state.location.name,
      predictedAqi: parseInt(els.verifyPredAqi?.textContent || '184', 10),
      predictedPm25: parseInt(els.verifyPredPm25?.textContent || '112', 10),
      horizon: state.verificationData.activeHorizon || '1h',
      vote,
      reason,
      otherText
    };

    try {
      const resp = await fetch('/api/verify-aqi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();

      if (vote === 'confirmed') {
        if (els.verifyBtnGroup) els.verifyBtnGroup.classList.add('hidden');
        if (els.verifySuccessBanner) els.verifySuccessBanner.classList.remove('hidden');
        showAuthToast('Thanks! Your observation supports this prediction.');
      } else {
        if (els.verifyDiscrepancySection) els.verifyDiscrepancySection.classList.add('hidden');
        if (els.verifyReportedBanner) els.verifyReportedBanner.classList.remove('hidden');
        showAuthToast('Thank you for reporting! Ground observations help calibrate regional AI models.');
      }

      if (data.stats) {
        state.verificationData.stats = data.stats;
        renderAgreementUi(data.stats);
      }
    } catch (err) {
      console.warn('AQI verify network fallback:', err);
      if (vote === 'confirmed') {
        if (els.verifyBtnGroup) els.verifyBtnGroup.classList.add('hidden');
        if (els.verifySuccessBanner) els.verifySuccessBanner.classList.remove('hidden');
      } else {
        if (els.verifyDiscrepancySection) els.verifyDiscrepancySection.classList.add('hidden');
        if (els.verifyReportedBanner) els.verifyReportedBanner.classList.remove('hidden');
      }
    }
  }

  async function submitFireVerification(observed, details = 'smoke', otherText = null) {
    const sessionId = sessionStorage.getItem('vayudrishti_session_id') || ('s_' + Date.now());
    sessionStorage.setItem('vayudrishti_session_id', sessionId);

    const payload = {
      sessionId,
      lat: state.location.lat,
      lng: state.location.lng,
      city: state.location.name,
      observed,
      details,
      otherText
    };

    try {
      const resp = await fetch('/api/verify-fire', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();

      const newConf = data.updatedConfidence != null ? data.updatedConfidence : (observed ? 92 : 72);
      state.verificationData.fireConfidence = newConf;
      renderFireConfidenceUi(newConf, newConf >= 75 ? 'Potential fire detected nearby' : (newConf >= 50 ? 'Smoke conditions likely' : 'No significant fire/smoke signal detected'));

      if (els.fireDetailsPanel) els.fireDetailsPanel.classList.add('hidden');
      if (els.fireVerifyBtnGroup) els.fireVerifyBtnGroup.classList.add('hidden');
      if (els.fireFeedbackBanner) {
        els.fireFeedbackBanner.classList.remove('hidden');
        if (observed) {
          if (els.fireFeedbackIcon) els.fireFeedbackIcon.textContent = '✓';
          if (els.fireFeedbackTitle) els.fireFeedbackTitle.textContent = 'Ground Truth Verified';
          if (els.fireFeedbackDesc) els.fireFeedbackDesc.textContent = `Your observation confirmed local smoke/fire. Confidence upgraded to ${newConf}%.`;
          showAuthToast(`Local fire/smoke confirmed! Alert confidence upgraded to ${newConf}%.`);
        } else {
          if (els.fireFeedbackIcon) els.fireFeedbackIcon.textContent = 'ℹ️';
          if (els.fireFeedbackTitle) els.fireFeedbackTitle.textContent = 'Observation Noted: Not Observed Locally';
          if (els.fireFeedbackDesc) els.fireFeedbackDesc.textContent = `Clear visibility recorded. Alert confidence attenuated to ${newConf}% without erasing satellite data.`;
          showAuthToast(`Observation noted: Not observed locally. Confidence calibrated to ${newConf}%.`);
        }
      }

      if (els.signalGroundText) {
        els.signalGroundText.textContent = observed
          ? 'Ground truth verified by your observation (+8% boost)'
          : 'Local operator reported clear visibility (-12% attenuation)';
      }

      updateSimulatorMapOverlays();
    } catch (err) {
      console.warn('Fire verification network error, applying local state:', err);
      const newConf = observed ? 92 : 72;
      state.verificationData.fireConfidence = newConf;
      renderFireConfidenceUi(newConf, observed ? 'Potential fire detected nearby' : 'Smoke conditions likely');
      if (els.fireDetailsPanel) els.fireDetailsPanel.classList.add('hidden');
      if (els.fireVerifyBtnGroup) els.fireVerifyBtnGroup.classList.add('hidden');
      if (els.fireFeedbackBanner) els.fireFeedbackBanner.classList.remove('hidden');
    }
  }

  // =========================================================================
  // REAL-TIME NOTIFICATIONS & ALERT CENTER
  // =========================================================================
  async function loadNotifications() {
    if (!els.notifListContainer) return;

    try {
      const cityParam = encodeURIComponent(state.location.name);
      const resp = await fetch(`/api/notifications?city=${cityParam}&lat=${state.location.lat}&lng=${state.location.lng}`);
      const data = await resp.json();

      if (data.success && data.notifications) {
        state.notifications = data.notifications;
        state.unreadNotifCount = data.unreadCount != null ? data.unreadCount : data.notifications.length;
        renderNotificationsList(data.notifications);
      }
    } catch (err) {
      console.warn('Notification fetch error:', err);
    }
  }

  function renderNotificationsList(notifs) {
    if (!els.notifListContainer) return;
    if (!notifs || notifs.length === 0) {
      els.notifListContainer.innerHTML = '<div style="padding:20px; text-align:center; color:var(--color-ink-subtle); font-size:12px;">No active environmental alerts for this area.</div>';
      if (els.notifUnreadBadge) els.notifUnreadBadge.style.display = 'none';
      if (els.notifActiveCountTag) els.notifActiveCountTag.textContent = '0 Active';
      return;
    }

    if (els.notifUnreadBadge) {
      els.notifUnreadBadge.textContent = notifs.length;
      els.notifUnreadBadge.style.display = 'flex';
    }
    if (els.notifActiveCountTag) {
      els.notifActiveCountTag.textContent = `${notifs.length} Active`;
    }

    let html = '';
    notifs.forEach(n => {
      const levelClass = n.level === 'HIGH_ALERT' ? 'level-high' : (n.level === 'WARNING' ? 'level-warning' : 'level-watch');
      const badgeClass = n.level === 'HIGH_ALERT' ? 'badge-high' : (n.level === 'WARNING' ? 'badge-warning' : 'badge-watch');

      let metaHtml = '';
      if (n.details) {
        if (n.details.distanceKm) metaHtml += `<span>Distance: <strong>${n.details.distanceKm} km</strong></span>`;
        if (n.details.windDirection) metaHtml += `<span>Wind: <strong>${n.details.windDirection}</strong></span>`;
        if (n.details.confidence) metaHtml += `<span>Confidence: <strong>${n.details.confidence}%</strong></span>`;
        if (n.details.predictedAqi) metaHtml += `<span>Predicted AQI: <strong>${n.details.predictedAqi}</strong></span>`;
        if (n.details.arrivalWindow) metaHtml += `<span>Arrival: <strong>${n.details.arrivalWindow}</strong></span>`;
      }

      html += `
        <div class="notif-item-card ${levelClass}">
          <div class="notif-item-top">
            <span class="notif-item-badge ${badgeClass}">${n.levelBadge || n.level}</span>
            <span class="notif-item-time">8m ago</span>
          </div>
          <h4 class="notif-item-title">${n.title}</h4>
          <p class="notif-item-msg">${n.message}</p>
          ${metaHtml ? `<div class="notif-item-meta">${metaHtml}</div>` : ''}
          <button type="button" class="notif-item-cta" data-action="${n.ctaAction || 'VIEW_MAP'}">
            <span>${n.ctaText || 'View Incident'} &rarr;</span>
          </button>
        </div>
      `;
    });

    els.notifListContainer.innerHTML = html;

    // Attach CTA listeners
    els.notifListContainer.querySelectorAll('.notif-item-cta').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const action = btn.getAttribute('data-action');
        handleNotificationAction(action);
      });
    });
  }

  function handleNotificationAction(action) {
    if (els.notifPopoverPanel) els.notifPopoverPanel.classList.add('hidden');

    if (action === 'VIEW_MAP' || action === 'VIEW_PLUME') {
      switchPage('page-routes-simulator');
      setTimeout(() => {
        if (els.simulatorMap) {
          els.simulatorMap.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    } else if (action === 'VIEW_PREDICTION') {
      switchPage('page-routes-simulator');
      setTimeout(() => {
        if (els.predictionVerifyCard) {
          els.predictionVerifyCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }
  }

  // 30-second polling for live sensor and notification feed
  function initEnvironmentalPolling() {
    if (environmentalPollInterval) clearInterval(environmentalPollInterval);
    environmentalPollInterval = setInterval(() => {
      if (state.isLoggedIn) {
        loadNotifications();
        if (state.currentPage === 'page-routes-simulator') {
          loadPredictionVerification();
        }
      }
    }, 30000);
  }

})();
