# Raw Environmental Datasets

This directory holds verified raw sensor data, historical CPCB / EPA telemetry logs, and satellite observations (e.g. Sentinel-5P, MODIS AOD).

Raw data must remain immutable and unedited.
